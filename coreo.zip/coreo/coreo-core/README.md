## COREO
Coreo是一套动态化解决方案，分为Coreo底层解析器、运行时环境(JSVM)、协议下发等能力

- Coreo底层解析器（当前库支持的能力）：作为底层解析能力，通过`babylon`解析转换成需要的JS源码和协议，功能支持：JSX转JS源码、JS转jsonSchema协议等
- 协议下发：通过解析后的JSON schema上传到服务端后存储，由线上IDE修改，下发。
- 运行时环境(JSVM)：通过协议下发解析协议内容，并在运行时环境中，解析执行。


## 方法
|名称|参数|返回值|描述|
|:---------------|:--------|:----|:----------|
|convertor| `ast` 抽象语法树 <br /> `pragma`  `JSX`解析前缀，默认值：`Coreo.render` |AST|转化器 将JSX转换成新的AST|
|protocol| `ast` 抽象语法树 |json schema|协议解析 将AST转化成json scheama 协议|
|generateProto| `code` 源码字符串内容 <br /> `pragma`  `JSX`解析前缀，默认值：`Coreo.render` |json schema|由源码生成协议|
|transformJSX| `code` JSX源码字符串内容 <br /> `pragma`  `JSX`解析前缀，默认值：`Coreo.render` |转换后的JS源码|JSX转换JS源码|