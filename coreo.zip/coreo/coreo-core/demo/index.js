/* import { styleObjectifier } from '../src/utils'


const styleText = `
.helloWorld {
  background-color: #ccc;
  background-image: url("https://g.alicnd.com/a.png");
  .child .hhh {
    color: #fff !important;
    font-weight: bold;
    --webkit-box: 1;
    .child-child {
      color: red;
    }
  }
}
.h1 {
  flex: fff;
  opaty: .1;
  line-clamp: 3;
}
`
const objectStyle = styleObjectifier(styleText)
console.log("objectStyle", objectStyle) */


import coreo from '../src'

const code = `
export default {
  onClick: async (abc = {}, ...args) => {
    const a = {
      aa: '1', bb: '2', cc: '3'
    }
    const b = 'aa'
    const c = a[b]
    const d = a.bb
    const e = a['cc']
  }
}
`

const proto = coreo.generateProto(code)

console.log(JSON.stringify(proto))

/* 
import { createElement } from 'rax';

import View from 'rax-view';
import Text from 'rax-text';
import Image from 'rax-image';
import { Coreo, setComponents } from '@ali/rb-coreo';
import coreo from '@ali/coreo-core'

const code = `
export default (<View style={style}>
    <View>
        <Image source={{uri: uri}} />
    </View>
    <View>
      <Text>test</Text>
    </View>
  </View>
)
`
const code1 = `
export default {
  state: {title: 'xx',style: {
    width: '500rpx',
    height: '500rpx',
    background: 'red'
  }, time: [1, 2], background: '#ff0000', uri: 'https://img.alicdn.com/imgextra/i1/6000000002024/O1CN01YTKUhD1Qp2JiFVhVv_!!6000000002024-2-octopus.png'},
  
  onClick: () => {
    const { title: t1, time } = this.state;
    const [ aaaa, bbbb = cccc ] = time;
    this.setState({ title: t1 > 10 ? \`title: \${t1}, finish!\` : t1 + 1 });
  }
}
`

const proto = coreo.generateProto(code);
const proto1 = coreo.generateProto(code1);
const logic = {"type":"obj","props":[]};

console.log(JSON.stringify(proto), proto1)
setComponents({ 'View': View, Text, Image });

function DynamicPreview() {
  return <Coreo schema={{ view: proto, logic: proto1 }} />
}

export default DynamicPreview;
*/
