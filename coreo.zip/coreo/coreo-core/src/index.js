import convertor from './lib/Convertor'
import protocol from './lib/Protocol'

import { generateProto, transformJSX, styleObjectifier } from './utils'

export default {
  convertor, // 转化器 将JSX转换成新的AST
  protocol, // 协议层 将AST转化成json scheama 协议
  generateProto, // 由源码生成协议
  transformJSX, // JSX转换JS源码
  styleObjectifier, // 样式转化器，将css书写的样式转化成内联样式
}