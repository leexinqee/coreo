import * as babylon from "babylon";
import generate from "babel-generator";
import postcss from 'postcss'
import Convertor from '../lib/Convertor'
import Protocol from '../lib/Protocol'
import objectifier from '../lib/objectifier'

/**
 * 源码文件编译生成协议schema
 * @param {*} code 源码文件 
 * plugins可选参数：[ estree, jsx, flow, doExpressions, objectRestSpread, decorators, classProperties, exportExtensions, asyncGenerators, functionBind, functionSent, dynamicImport, templateInvalidEscapes ]
 * @returns 返回通信协议的schema对象
 */
export function generateProto(code = '', pragma = 'Coreo.render') {
  if (!code) return ''

  let ast = null
  try {
    ast = babylon.parse(code, {
      sourceType: "module",
      plugins: ["jsx", 'objectRestSpread']
    });
  } catch (error) {
    throw new Error("源码中存在不可解析的语法错误，请检查源代码", error)
  }

  if (!ast) return ''

  const newAst = Convertor(ast, pragma)
  const result = Protocol(newAst)

  return result
}

/**
 * JSX文件转换成解析后表达的源码文件
 * @param {*} code 源码文件
 * @returns 
 */
export function transformJSX(code = '', pragma = 'Coreo.render') {
  if (!code) return ''

  let ast = null
  try {
    ast = babylon.parse(code, {
      sourceType: "module",
      plugins: ["jsx", 'objectRestSpread']
    });
  } catch (error) {
    throw new Error("源码中存在不可解析的语法错误，请检查源代码", error)
  }

  if (!ast) return ''

  const newAst = Convertor(ast, pragma)

  const generateCode = generate(newAst, {
    compact: true, // 去掉空格
    comments: true, // 去掉注释
    minified: true, // 是否压缩代码
  }).code

  return generateCode
}


/**
 * CSS样式转化器
 * @param {*} code 
 * @returns 
 */
export function styleObjectifier(code = '') {
  let styleRoot = null
  try {
    styleRoot = postcss.parse(code)
  } catch (error) {
    throw new Error("css解析错误，语法不可解析", error)
  }
  if (!styleRoot) return ''

  return objectifier(styleRoot)
}
