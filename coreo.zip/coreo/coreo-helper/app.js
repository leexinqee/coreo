'use strict';
const path = require('path');
const fs = require('fs');
const coreo = require('@ali/coreo-core').default;

module.exports = app => {
  app.getPageContent = page => {
    if (!page) {
      return {};
    }
    const pagePath = path.join(__dirname, 'app/pages/', page);

    const jsxFile = path.join(pagePath, './index.xml');
    const jsFile = path.join(pagePath, './index.js');
    const cssFile = path.join(pagePath, './index.css');
    const jsonFile = path.join(pagePath, './index.json');

    const jsxFileContent = fs.readFileSync(jsxFile).toString();
    const jsFileContent = fs.readFileSync(jsFile).toString();
    const cssFileContent = fs.readFileSync(cssFile).toString();
    const jsonFileContent = fs.readFileSync(jsonFile).toString();

    const tJsxCode = `export default (${jsxFileContent})`;
    const j = JSON.stringify(coreo.generateProto(tJsxCode));
    const a = JSON.stringify(coreo.generateProto(jsFileContent));
    const s = JSON.stringify(coreo.styleObjectifier(cssFileContent));

    const ships = {
      j: JSON.parse(j || '{}'),
      a: JSON.parse(a || '{}'),
      s: JSON.parse(s || '{}'),
      d: JSON.parse(jsonFileContent || '{}'),
      n: page,
      v: '0.0.1',
    };

    return ships;
  };
};
