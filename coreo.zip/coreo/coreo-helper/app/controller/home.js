'use strict';

module.exports = app => {
  class HomeController extends app.Controller {
    async page() {
      const { ctx } = this;
      const pageParams = ctx.params.page;
      const pages = pageParams.split('|');
      const pageContents = pages.map(page => app.getPageContent(page));

      ctx.body = {
        // 页面投放组件列表
        p: pageContents,
      };
    }
  }
  return HomeController;
};
