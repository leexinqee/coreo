export default {
  properties: {},
  state: {},
  onInit() {
    const start = Date.now();

    /* function poll100() {for (let index = 0; index < 100; index++) {}}
    function poll1000() {for (let index = 0; index < 1000; index++) {}}
    
    const times = 100
    for (let index = 0; index < times; index++) {for (let index = 0; index < 100; index++) {}}
     */

    function formatDistance(distance) {
      const intMeter = parseInt(distance, 10);
      if (intMeter < 1000) return `${intMeter}米`;
      
      return '大于99公里';
    }
    const distance = formatDistance(100000)
    console.log("distance", distance)

    const end = Date.now()
    console.log("执行性能测试时间", start, end, end - start)
  }
}