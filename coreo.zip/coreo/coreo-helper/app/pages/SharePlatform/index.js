export default {
  getPageShare(params) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve({
          title: '测试动态化',
          path: '/pages/Shop/index',
          imageUrl: 'https://gw.alicdn.com/imgextra/i3/O1CN01lakDKn27bmMWke3Wt_!!6000000007816-2-tps-420-336.png',
        })
      }, 1000)
    })
  }
}