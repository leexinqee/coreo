export default {
  properties: {
    scenes,
    className,
    stationCode,
    firstScreenFinished,
    flashSaleOffers,
    flashSaleConfig,
    currentTab,
    onClickToAll,
    onOfferAppear,
    onOfferClick,
    onClickAll,
    isOlderMode
  },
  state: {},
  onInit() {}
}