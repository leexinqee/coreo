export default {
  properties: {},
  state: {},
  onInit() {}
}