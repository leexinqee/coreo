export default {
  properties: {
    isSticky,
    isOlderMode,
    currentKey,
    nextKey,
    onClick,
    firstScreenFinished,
    doing
  },
  state: {},
  onInit() {}
}