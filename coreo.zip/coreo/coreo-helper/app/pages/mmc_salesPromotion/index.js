export default {
  properties: {
    hotSaleProps,
    flashSaleProps,
    pageData
  },
  state: {
    activeIndex: null
  },
  tabRef: null,
  onInit() {
    console.log('onInit: ', this.properties)
  },
  touchRef(index, ref) {
    this.tabRef = ref
    setTimeout(() => {
      this.tabRef && this.tabRef.scrollIntoView({ id: 'flashTab-'+index, duration: 300 })
    }, 100)
  },
  showAllHandle() {
    const flash = getGlobal("flashSalePropsArgs")
    flash.handleClickToAll()
  }
}