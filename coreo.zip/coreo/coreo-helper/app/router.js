'use strict';

module.exports = app => {
  app.get('/coreo/:page', 'home.page');
};
