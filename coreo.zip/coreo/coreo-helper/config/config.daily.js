/**
 * 日常配置
 */

'use strict';
