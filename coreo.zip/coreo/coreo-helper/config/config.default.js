/**
 * 默认配置，所有环境都会加载此配置
 * @see http://gitlab.alibaba-inc.com/egg/begg#%E9%85%8D%E7%BD%AE
 *
 * antx 相关配置, 建议都迁移到 config 配置管理
 * @see http://gitlab.alipay-inc.com/chair/chair/issues/1612
 *
 * - config.default.js - 默认配置，所有环境都会加载此配置
 * - config.unittest.js - gitlab 上执行 ci 环境配置,会和 default 配置合并（覆盖）
 * - config.local.js - 本地开发配置，在本地开发的时候会和 default 配置合并（覆盖）
 * - config.project.js - 项目测试环境配置，在项目测试环境的时候会和 default 配置合并（覆盖）
 * - config.daily.js - 配置，在日常的时候会和 default 配置合并（覆盖）
 * - config.pre.js - 预发配置，在预发的时候会和 default 配置合并（覆盖），注意，如果没有此文件，则在预发下使用 prod 的配置
 * - config.prod.js - 生产配置，在生产环境的时候会和 default 配置合并（覆盖）
 *
 */

'use strict';

module.exports = appInfo => {
  const config = exports = {};

  // use for cookie sign key, should change to your own and keep security
  config.keys = appInfo.name + '_1631070955556_875';

  // 这个配置用于停止自动扫描目录
  config.container = {
    disableAutoLoad: true
  };

  config.bucLogin = {
    // appname: 'appname', // 必填，需要应用去
    // ignore: '/api', // 哪些路径可以不经过登陆访问，可以传正则或者方法（https://github.com/koajs/userauth）
    // match: '/pages', // 指定哪些路径必须要登陆访问，可以传正则或者方法
  };

  // add your config here
  config.middleware = [];

  config.view = {
    defaultViewEngine: 'nunjucks',
    mapping: {
      '.html': 'nunjucks',
    },
  };

  return config;
};
