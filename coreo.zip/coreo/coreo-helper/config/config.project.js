/**
 * 项目测试环境配置
 */

'use strict';
