'use strict';

module.exports = {
  view: true,
  xtpl: false,
  nunjucks: true,
  nunjucksEnhance: true
};
