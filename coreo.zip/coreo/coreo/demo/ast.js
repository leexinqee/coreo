import { createElement, render } from 'rax';
import DriverUniversal from 'driver-universal';
import { useCoreo, setComponents, setAbilities, utils } from '@ali/rb-coreo';

console.log({utils});
setComponents({
  Test: (props) => <div>{props.children}</div>
});
setAbilities({
  Test: () => alert('test')
});

function Home() {
  const { floors } = useCoreo({
    ossAddress: 'https://mmcfile.oss-cn-zhangjiakou.aliyuncs.com/tfile/229df6ab717c4c59814f259a29366312?Expires=4781159879&OSSAccessKeyId=LTAI5tAWGC7NkPFr7DpMWJu4&Signature=VFddmCqlXWV4c4b4lMirA5UANdw%3D'
  });
  return <div>{floors}</div>;
}

render(<Home />, document.getElementById('root'), { driver: DriverUniversal });
