import { useState, useEffect } from 'rax';
import { ast } from '../utils/magic';
import { components, render, setComponent } from '../utils/render';

// 全局变量的设置
const setGlobal = (key, value) => {
  if (!getApp().__global) getApp().__global = {};
  getApp().__global[key] = value;
};
const getGlobal = (key) => {
  if (!getApp().__global) return null;
  return getApp().__global[key];
};

export const functions = {};
export const setAbilities = (funcs) => {
  Object.keys(funcs).forEach((key) => {
    functions[key] = funcs[key];
  });
};
export const setComponents = (obj) => {
  Object.keys(obj).forEach((key) => {
    setComponent(key, obj[key]);
  });
};
export { components };
export const Coreo = (props) => {
  const { schema, localProps = {} } = props;
  const { logic, view, style } = schema;
  let { state: logicState = {}, properties = {} } = ast(logic, [{}]);
  const [state, setState] = useState(logicState);

  // 将远程properties与本地localProps映射：
  // 1、如果本地localProps没有该属性，抛出异常；
  // 2、如果远程properties设置了默认值，优先使用默认值
  Object.keys(properties)?.map((name) => {
    if (!localProps[name]) {
      console.warn(`'${name}' in properties is not found in localProps`);
    }
    properties[name] = properties[name] || localProps[name];
  });

  const scope = {
    ...functions,
    Coreo: { render },
    getApp,
    window,
    JSON,
    setGlobal,
    getGlobal,
    console,
    setTimeout,
    setInterval,
    Date,
    Math,
    parseInt,
    parseFloat,
    Promise,
    decodeURIComponent,
    encodeURIComponent,
    style,
    localProps,
    wx: typeof wx !== 'undefined' ? wx : null,
    _r: render,
    _this: {
      properties,
      state,
      setState: (s) => {
        setState({
          ...state,
          ...s,
        });
      },
    },
  };
  const logicScope = ast(logic, [scope]);

  useEffect(() => {
    if (logicScope.onInit) {
      logicScope.onInit();
    }
  }, []);

  // 如果state中属性与properties以及localProps中属性重复，抛出异常
  Object.keys(state).map((name) => {
    if (properties[name] || localProps[name]) {
      throw new Error(`'${name}' in state has already been declared in properties or localProps`);
    }
  });

  return ast(view, [{ ...scope, ...logicScope, localProps, ...properties, ...state }]);
};
