import { createElement, useState, useEffect } from 'rax';
import { Coreo } from '../components/coreo-component';
import { getOSSData } from '../utils/utils';

function useCoreo(config) {
  const {
    plugin: initPlugin = [],
    ossAddress,
    components: initComponents = {},
    props: localProps = {},
    mock,
  } = config;

  const [res, setRes] = useState({});
  const [state, setState] = useState({});
  const [plugin, setPlugin] = useState({});
  const [error, setError] = useState(false);
  const updateState = (newState) => {
    setState({ ...state, ...newState });
  };

  // 获取最终投放数据
  const getPageProtoData = () => {
    if (mock) {
      setRes(mock);
    } else {
      getOSSData(ossAddress)
        .then((res) => {
          if (res.p && res.p.length > 0) {
            setRes(res);
          } else {
            setError(true); // 未投放页面走兜底方案
          }
        })
        .catch((e) => {
          console.error('OSS数据下载异常', e);
          setError(true);
        });
    }
  };

  useEffect(() => {
    // 获取页面投放数据
    getPageProtoData();
    setPlugin(initPlugin.map((plugin) => plugin({ updateState, state })));
  }, []);

  const components = {};

  try {
    (res?.p || []).forEach((tag, index) => {
      const { n: name } = tag;
      const view = tag.j || {};
      const logic = tag.a || {};
      const style = tag.s || {};

      const component = (
        <Coreo key={`${name}-${index}`} schema={{ view, logic, style }} localProps={localProps} />
      );

      components[name] =
        typeof initComponents[name] === 'function'
          ? initComponents[name]({ state, localProps, updateState, logic, view, component })
          : component;
    });
  } catch (e) {
    console.error('e:', e);
    setError(true);
  }

  return {
    plugin,
    state,
    error,
    localProps,
    updateState,
    components,
    floors: Object.keys(components).map((k) => components[k]),
  };
}

export default useCoreo;
