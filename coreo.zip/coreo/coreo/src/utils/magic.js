export const ast = (obj, scope = [{}]) => {
  if (typeof obj !== 'object' || !obj) return obj;

  if (Array.isArray(obj)) {
    for (let i = 0; i < obj.length; i++) {
      const result = ast(obj[i], scope);

      if (typeof result === 'object' && result.return) {
        return result;
      }
    }
    return;
  }

  const getValue = (name) => {
    for (let i = scope.length - 1; i >= 0; i--) {
      if (name in scope[i]) return scope[i][name];
      if (i === 0) return scope[i][name];
    }
  };
  const setValue = (name, value) => {
    scope[scope.length - 1][name] = value;
  };
  const setDefinedValue = (name, value) => {
    for (let i = scope.length - 1; i >= 0; i--) {
      if (name in scope[i]) {
        scope[i][name] = value;
        return;
      }
      if (i === 0) {
        throw `${name} is not defined`;
      }
    }
  };
  const varDefine = () => {
    const nameList = ast(obj.name, scope);
    const value = ast(obj.value, scope);

    if (typeof nameList === 'string') {
      return setValue(nameList, value);
    }
    // name, alias, defaultValue
    nameList.forEach(({ name, alias, defaultValue }) => {
      setValue(alias, typeof value[name] === 'undefined' ? defaultValue : value[name]);
    });
  };

  switch (obj.type) {
    case 'const':
      return varDefine();
    case 'var':
      return varDefine();
    case 'let':
      return varDefine();
    case 'objPattern':
      return obj.props.map((prop) => ast(prop, scope));
    case 'assignment':
      return {
        name: obj.name,
        alias: obj.alias,
        defaultValue: ast(obj.defaultValue, scope),
      };
    case 'arr':
      let arrList = [];
      (obj.elements || []).forEach((ele) => {
        if (ele && ele.type === 'spread') {
          // todo webpack编译为 .concat 与...展示不一致
          arrList = [...arrList, ...ast(ele.argument, scope)];
        } else {
          arrList.push(ast(ele, scope));
        }
      });

      return arrList;
    case 'set':
      return ast(obj.value, scope);
    case 'obj':
      const { props = [] } = obj;
      let objele = {};

      props.forEach((prop) => {
        if (prop.name) {
          const name = ast(prop.name, scope);
          objele[name] = ast(prop, scope);
        } else if (prop.type === 'spread') {
          objele = {
            ...objele,
            ...ast(prop.argument, scope),
          };
        }
      });

      return objele;
    case 'identifier':
      return getValue(obj.name);
    case 'this':
      return getValue('_this') || {};
    case 'member':
      const { object, prop, computed } = obj;

      // 如果有变量申明的值，取变量值
      let propName = null
      if (typeof prop === 'string') {
        propName = prop
      } else {
        if (computed) {
          const hasName = ast(prop, scope)
          propName = hasName !== undefined ? hasName : prop.name
        } else {
          propName = prop.name
        }
      }

      if (typeof object === 'string') {
        const memberMain = getValue(object);

        if (!memberMain) {
          throw `${object} is not found`;
        }
        const memberSub = memberMain[propName];

        if (!memberMain) {
          throw `cannot find ${object} from scope: ${JSON.stringify(scope)}`;
        }
        return typeof memberSub === 'function' ? memberSub.bind(memberMain) : memberSub;
      } else {
        const memberMain = ast(object, scope);
        const memberSub = memberMain[propName];
        // member
        return typeof memberSub === 'function' ? memberSub.bind(memberMain) : memberSub;
      }
    case 'exp':
      const { operator, left, right } = obj;
      const compare = {
        '+': (a, b) => a + b,
        '-': (a, b) => a - b,
        '*': (a, b) => a * b,
        '/': (a, b) => a / b,
        '%': (a, b) => a % b,
        '==': (a, b) => a == b,
        '>=': (a, b) => a >= b,
        '<=': (a, b) => a <= b,
        '<': (a, b) => a < b,
        '>': (a, b) => a > b,
        '&': (a, b) => a & b,
        '&&': (a, b) => a && b,
        '|': (a, b) => a | b,
        '||': (a, b) => a || b,
        '===': (a, b) => a === b,
        '^': (a, b) => a ^ b,
        '!=': (a, b) => a != b,
        '!==': (a, b) => a !== b,
        '>>': (a, b) => a >> b,
        '<<': (a, b) => a << b,
        in: (a, b) => a in b,
      };
      const expRight = ast(right, scope);

      if (operator === '=') {
        if (typeof left === 'string') {
          setDefinedValue(left, expRight);
        } else if (left.type === 'identifier') {
          setValue(left.name, expRight);
        } else if (left.type === 'member') {
          const leftObj = ast(left.object, scope);
          let leftExp = leftObj;
          if (typeof leftExp === 'string') {
            leftExp = getValue(leftExp);
          }
          const key = left.prop.name ? left.prop.name : left.prop;
          leftExp[key] = expRight;
        } else {
          throw `exp暂不支持${left.type}, ${obj}`;
        }
      } else {
        const expLeft = ast(left, scope);
        if (!compare[operator]) {
          throw `${operator} is not support in 'exp', left exp is: ${left}, right exp is: ${right}`;
        }
        return compare[operator](expLeft, expRight);
      }
      break;
    case 'return':
      return {
        return: true,
        value: ast(obj.argument, scope)
      };
    case 'call':
      const { name, args } = obj;
      const callFunction = ast(name, scope);

      if (!callFunction) {
        console.error('function不存在', { name, scope });
      }
      // todo check null
      return callFunction(...args.map((arg) => ast(arg, scope)));
    case 'unary':
      const { argument, prefix } = obj;
      const unaryHelper = {
        '!': (a) => !a,
        '~': (a) => ~a,
        '++': (a, arg) => {
          ast({
            type: 'exp',
            operator: '=',
            left: {
              type: 'identifier',
              name: arg.name
            },
            right: {
              type: 'exp',
              left: a,
              operator: '+',
              right: 1
            },
          }, scope);
          return prefix ? a + 1 : a;
        },
        '--': (a, arg) => {
          ast({
            type: 'exp',
            operator: '=',
            left: {
              type: 'identifier',
              name: arg.name
            },
            right: {
              type: 'exp',
              left: a,
              operator: '-',
              right: 1
            }
          }, scope);
          return prefix ? a - 1 : a;
        }
      };

      return unaryHelper[obj.operator](ast(argument, scope), argument, prefix);
    case 'func':
      const { body: funcBody, args: funcArgs = [] } = obj;
      const func = (...funcParams) => {
        const addon = {};
        funcArgs.forEach((arg, index) => {
          if (arg.type === 'identifier') {
            addon[arg.name] = funcParams[index];
          } else if (arg.type === 'rest') {
            addon[arg.argument.name] = funcParams.slice(index);
          }
        });
        const result = ast(funcBody, [...scope, addon]);
        return result && result.return ? result.value : result;
      };

      if (obj.name) {
        setValue(typeof obj.name === 'object' ? obj.name.name : obj.name, func);
      }
      return func;
    case 'if':
      const { test: ifTest, body: ifBody, alter: ifAlter } = obj;
      const ifCondition = ast(ifTest, scope);

      if (ifCondition) {
        return ast(ifBody, scope);
      } else if (ifAlter) {
        return ast(ifAlter, scope);
      } else {
        return;
      }
    case 'new':
      const { name: newName, args: newArgs = [] } = obj;
      const newObj = ast(newName, scope);

      if (!newObj) {
        throw `new operation cannot find ${JSON.stringify(newName)}`;
      }
      // eslint-disable-next-line new-cap
      return new newObj(...newArgs.map((arg) => ast(arg, scope)));
    case 'block':
      const { body: blockBody } = obj;
      return ast(blockBody, [...scope, {}]);
    case 'for':
      const { init, test, update, body } = obj;
      const localScope = [...scope, {}];
      ast(init, localScope);

      while (ast(test, localScope)) {
        ast(body, localScope);
        ast(update, localScope);
      }

      return;
    case 'conditional':
      const { test: condTest, consequent: condConseq, alter: condAlter } = obj;
      return ast(ast(condTest, scope) ? condConseq : condAlter, scope);
    case 'template':
      const { exps: tempExps, quasis: tempQuasis } = obj;
      return tempQuasis.map((quasis, index) => `${ast(quasis, scope)}${ast(tempExps[index] || '', scope)}`).join('');
    default:
      console.log('不支持的类型', obj.type);
  }
};

export default ast;