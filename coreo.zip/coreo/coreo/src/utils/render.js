import { createElement, Fragment } from 'rax';
import { convertStyle } from './utils';

import View from 'rax-view';
import Text from 'rax-text';
import Image from 'rax-image';
import ScrollView from 'rax-scrollview';

export const components = {
  View,
  Text,
  Image,
  Fragment,
  ScrollView,
};
export const setComponent = (name, tag) => ((components[name] = tag), components);
export const getComponent = (name) => components[name];

export const render = (component, componentProps, ...children) => {
  const Tag = components[component] || Fragment;
  const { style, ...props } = componentProps || {};

  // 将自定义内敛样式转成字符串，用于挂在到微信原生组件中
  const customInlineStyle = props?.customInlineStyle && convertStyle(props?.customInlineStyle);

  let xStyle = style || {};
  if (props['x-style'] && Array.isArray(props['x-style'])) {
    xStyle = props['x-style'].reduce((pre, item) => ({ ...pre, ...(item || {}) }), {});
  }

  if (children) {
    return (
      <Tag
        x-if={props['x-if'] === false ? false : true}
        x-elseif={props['x-elseif'] === false ? false : true}
        x-else={props['x-else'] === false ? false : true}
        x-class={props['x-class']}
        style={xStyle}
        {...props}
        customInlineStyle={customInlineStyle}
        className={props?.className}
      >
        {children}
      </Tag>
    );
  }
  return <Tag {...props} />;
};
