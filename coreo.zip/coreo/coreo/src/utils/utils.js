import Api from '@ali/mmc-universal-api';
import { ast } from './magic';
import { render } from './render';

// 通过OSS上传的数据，获取OSS数据
export const getOSSData = (requestUrl = '') => {
  if (!requestUrl) return Promise.reject('');

  return Api.request({
    method: 'get',
    url: requestUrl,
    header: {
      'Content-Type': ' ', // 必须为空格符
    },
    headers: {
      'Content-Type': ' ', // 必须为空格符
    },
  }).then((res) => res.data);
};

/**
 * style对象转换为字符串
 */
export const convertStyle = (style = {}) => {
  let styleStr = '';

  Object.keys(style).forEach((name) => {
    let styleName = name;
    (name.match(/[A-Z]/g) || []).forEach((up) => {
      styleName = styleName.replace(up, `-${up.toLocaleLowerCase()}`);
    });

    styleStr += `${styleName}:${style[name]};`;
  });

  return styleStr;
};

export const ast2json = (schema, defScope) => {
  const render = (tagName, defProps, ...children) => {
    const props = defProps || {};
    const styleStr = convertStyle(props.style);
    const name = `${tagName}`.toLowerCase();

    return {
      name,
      style: `${styleStr}`,
      props: {
        ...props,
        style: `${styleStr}`,
        hasOnClick: !!props.onClick,
      },
      // 兼容 children: [ [1, 2, 3] ] 的情况
      // 通常使用[].map(...)之后会出现
      children: children.map((child) =>
        Array.isArray(child) ? { name: 'block', children: child } : child
      ),
    };
  };

  const { view, logic } = schema;
  // 获取logic中默认state
  const { state: logicState } = ast(logic, [{}]);
  // 整合动态运行支持的上下文
  const scope = {
    Coreo: { render },
    console: typeof console !== 'undefined' ? console : null,
    setTimeout,
    setInterval,
    Date,
    Math,
    Promise,
    wx: typeof wx !== 'undefined' ? wx : null,
    my: typeof my !== 'undefined' ? my : null,
    _r: render,
    _this: {
      state: logicState,
      setState: (newState) => {
        const state = {
          ...this.data.state,
          ...newState,
        };

        componentScope._this.state = state;
        this.setData({
          state,
          realDom: ast(view, [{ ...componentScope, ...newState }]),
        });
      },
    },
    ...defScope,
  };
  const logicScope = ast(logic, [scope]);
  const componentScope = { ...scope, ...logicScope, ...logicScope.state };

  // 生成渲染子组件的json
  return ast(view, [componentScope]);
};

// 单schema执行
export const execAst = (schema, defScope = {}, mock = null) => {
  const { a: logic, s: style } = mock || schema;
  const scope = {
    Coreo: { render },
    getApp,
    window,
    JSON,
    console: typeof console !== 'undefined' ? console : null,
    setTimeout,
    setInterval,
    Date,
    Math,
    Promise,
    decodeURIComponent,
    encodeURIComponent,
    style,
    wx: typeof wx !== 'undefined' ? wx : null,
    _r: render,
    ...(defScope || {})
  }

  return ast(logic, [scope]);
}
