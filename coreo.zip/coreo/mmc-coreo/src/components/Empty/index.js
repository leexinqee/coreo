import React from 'react'

const styles = {
  container: {
    display: 'flex',
    width: '100%',
    alignItems: 'center',
    flexDirection: 'column',
    height: 300,
    justifyContent: 'center',
    border: '1px solid #dfdfdf'
  }
}

export default function Empty({ content = '数据为空' }) {
  return (
    <div style={styles.container}>
      <svg t="1611145758097" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4520" width="70" height="70"><path d="M839.2 101.3H184.9L65.3 539.5 64 922.7h896V549.3l-120.8-448zM241.9 176h540.3L884 549.3H678.7l-74.7 112H420l-74.7-112H140.1L241.9 176z" p-id="4521" fill="#bfbfbf"></path></svg>
      <span style={{color: "#bfbfbf"}}>{content}</span>
    </div>
  )
}
