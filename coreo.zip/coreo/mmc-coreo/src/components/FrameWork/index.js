import React from 'react'
import { Nav, Shell } from '@alifd/next';
const { SubNav, Item } = Nav;
import styles from './index.module.scss'

export default function FrameWork({ children, title, action, selectKey = 1 }) {
  const goTo = (link) => window.location.href = link

  return (
    <Shell className={styles.shell} device="desktop" style={{ border: "1px solid #eee" }}>
      <Shell.Branding>
        <span className={styles.logo}>C-OREO</span>
        { title && (<span className={styles.subtitle}>{title}</span>) } 
      </Shell.Branding>
      <Shell.Navigation>
        <Nav embeddable defaultSelectedKeys={[`0-${selectKey - 1}`]}>
          <Nav.Item icon="chart-pie" onClick={goTo.bind(null, '../list/index.html')}>组件管理</Nav.Item>
          <Nav.Item icon="calendar" onClick={goTo.bind(null, '../putlist/index.html')}>页面管理</Nav.Item>
          <Nav.Item icon="set" onClick={goTo.bind(null, '../osstool/index.html')}>OSS小工具</Nav.Item>
        </Nav>
      </Shell.Navigation>
      <Shell.Action>{action}</Shell.Action>
      <Shell.Content className={styles.content}>{children}</Shell.Content>
    </Shell>
  )
}