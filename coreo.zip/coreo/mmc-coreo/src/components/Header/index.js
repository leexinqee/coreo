import React from 'react'
import { getEnv } from '@/utils'
import styles from './index.module.scss';

const env = getEnv()
const envText = env === 'daily' ? '日常' : env === 'pre' ? '预发' : env === 'prod' ? '线上' : '--'

export default function Env(props) {
  return (
    <header className={styles.header}>
      <div className={styles.headerTitle}>
        <span style={{ fontSize: 40 }}>C-OREO</span>
        <span style={{ fontSize: 20, marginLeft: 5 }}>({props.title})</span>
        <span style={{ fontSize: 14, marginLeft: 5, color: 'orange' }}>当前环境：{envText}</span>
      </div>
      <div className={styles.buttonGroup}>
        {props.right}
      </div>
    </header>
  )
}
