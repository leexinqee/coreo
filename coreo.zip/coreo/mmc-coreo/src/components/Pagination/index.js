import React, { useState } from 'react'
import { Pagination } from '@alifd/next'

export default function index({ page = 1, total = 0, onChange = () => {} }) {

  const [current, setCurrent] = useState(page)

  const onPageChange = (page) => {
    setCurrent(page)
    onChange(page)
  }

  return total ? (
    <div style={{ display: 'flex', justifyContent: 'flex-end', margin: '0 20px' }}>
      <Pagination current={current} onChange={onPageChange} style={{ marginTop: 10 }} total={total} />
    </div>
  ) : null
}
