import React, { Component } from 'react';
import moment from 'moment'
import { isEqual, cloneDeep } from 'lodash'
import {
  Checkbox,
  Input,
  Button,
  Select,
  NumberPicker,
  DatePicker,
  Form
} from '@alifd/next';
import {
  FormBinderWrapper as IceFormBinderWrapper,
  FormBinder as IceFormBinder,
  FormError as IceFormError,
} from '@icedesign/form-binder';

const { Combobox } = Select;
const { RangePicker, MonthPicker } = DatePicker;

class SearchFiled extends Component {

  constructor(props) {
    super(props)
    this.rangeBindValue = {}
    this.state = {
      config: props.config,
      value: { ...this.props.value },
      flag: true
    }
  }

  handleSubmit = () => {
    this.refs.form.validateAll((errors, values) => {
      if (errors) return;
      this.props.search({ ...values, ...this.rangeBindValue });
    });
  };

  clear = () => {
    this.rangeBindValue = {}
    this.props.config.map(item => {
      if (item.component == 'RangePicker') {
        item.formBinderProps.setFieldValue = (v) => v || []
      }
    })
    this.setState({
      value: {},
      flag: false
    }, () => {
      this.props.search({});
    })
  }

  setValue = (object) => {
    setTimeout(() => {
      this.setState({
        value: {
          ...this.state.value,
          ...object
        }
      })
    }, 100);
  }


  _wrapComponent = (item, children, error = true) => {
    return (
      <Form.Item label={item.label} key={item.label || Date.now()} labelCol={{ fixedSpan: item.labelWidth || 5 }}>
        <IceFormBinder {...item.formBinderProps}>{children}</IceFormBinder>
        {error && <IceFormError name={item.formBinderProps.name} style={styles.error} />}
      </Form.Item>
    )
  }

  renderInput = (item) => {
    const children = <Input {...item.componentProps} hasClear style={{ width: `${item.width || 200}px` }} />
    return this._wrapComponent(item, children)
  };

  renderNumberPicker = (item) => {
    const children = <NumberPicker {...item.componentProps} />
    return this._wrapComponent(item, children)
  };

  renderCheckbox = (item) => {
    const children = <Checkbox {...item.componentProps}>{item.label}</Checkbox>
    return this._wrapComponent(item, children, false)
  };

  // rangePikcer方式重新bind值
  onRangeChange = (record, val) => {
    console.log("val", val)
    const [startKey, endKey] = record.description.bindingName || []
    const [startTime, endTime] = val || []
    this.rangeBindValue = {
      [record.formBinderProps.name]: null,
      [startKey]: startTime ? moment(startTime).format('YYYY-MM-DD') : '',
      [endKey]: endTime ? moment(endTime).format('YYYY-MM-DD') : ''
    }
    this.setState({ flag: false })
  }
  renderRangePicker = (item) => {
    const children = <RangePicker onChange={this.onRangeChange.bind(this, item)} {...item.componentProps} />
    if (item.formBinderProps.setFieldValue && this.state.flag) {
      this.onRangeChange(item, item.formBinderProps.setFieldValue())
    }
    return this._wrapComponent(item, children, false)
  };

  renderDatePicker = (item) => {
    const children = <DatePicker {...item.componentProps} />
    return this._wrapComponent(item, children, false)
  };

  renderMonthPicker = (item) => {
    const children = <MonthPicker {...item.componentProps} />
    return this._wrapComponent(item, children, false)
  };

  renderSelect = (item) => {
    const children = <Select {...item.componentProps} hasClear style={{ width: `${item.width || 200}px` }} />
    return this._wrapComponent(item, children);
  };

  renderCombobox = (item) => {
    const children = <Combobox {...item.componentProps} hasClear />
    return this._wrapComponent(item, children, false)
  };

  renderButton = (item) => {
    return (
      <Form.Item key={item.label || Date.now()}>
        <Button type={item.type} onClick={this.handleSubmit}>{item.label}</Button>
      </Form.Item>
    );
  };

  renderButtons = (item) => {
    return (
      <Form.Item key={item.label || Date.now()} style={{ marginLeft: 14 }}>
        {
          item.buttons.map(it => {
            return <Button key={it.label || Date.now()} type={it.type} onClick={it.do === 'search' ? this.handleSubmit : this.clear} style={styles.buttons}>{it.label}</Button>
          })
        }
      </Form.Item>
    );
  };

  renderFromItem = (config) => {
    return config.map((item) => {
      switch (item.component) {
        case 'Input':
          return this.renderInput(item);
        case 'Checkbox':
          return this.renderCheckbox(item);
        case 'Select':
          return this.renderSelect(item);
        case "DatePicker":
          return this.renderDatePicker(item);
        case "MonthPicker":
          return this.renderMonthPicker(item);
        case 'RangePicker':
          return this.renderRangePicker(item);
        case 'NumberPicker':
          return this.renderNumberPicker(item);
        case 'Combobox':
          return this.renderCombobox(item);
        case 'Button':
          return this.renderButton(item);
        case 'ButtonArr':
          return this.renderButtons(item);
        default:
          return this.renderInput(item);
      }
    });
  };

  onChange = (value) => {
    this.setState({ value })
  }

  render() {
    const { config } = this.props;
    const { value } = this.state
    return (
      <IceFormBinderWrapper ref="form" value={value} onChange={this.onChange}>
        <Form inline size='medium' labelAlign='left' labelTextAlign='right'>
          {this.renderFromItem(config)}
        </Form>
      </IceFormBinderWrapper>
    );
  }
}

const styles = {
  error: {
    marginLeft: '10px'
  },
  buttons: {
    margin: '0 5px'
  }
};

export default SearchFiled;
