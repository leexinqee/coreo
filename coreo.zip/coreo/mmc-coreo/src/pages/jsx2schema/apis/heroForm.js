import axios from 'axios'
import CsrfToken from '@ali/lst-csrf-token';
import request from '../../../utils/request'

// 创建schema
export function createSchema(data = {}) {
  return request({
    url: '/apis/heroform/createSchema',
    method: 'post',
    data
  })
}

// 更新schema
export function updateSchema(data = {}) {
  return request({
    url: '/apis/heroform/updateSchema',
    method: 'post',
    data
  })
}

// 创建schema
export function getSchemaListByType(params = {}) {
  return request({
    url: '/apis/heroform/getBatchByType',
    method: 'get',
    params
  })
}

// 创建schema
export function getSchemaList(params = {}) {
  return request({
    url: '/apis/heroform/getSchemaList',
    method: 'get',
    params
  })
}

// 通过名称获取schema： name_version 格式，如果不传version 返回当前name的最新正式版本
export function getSchemaByName(params = {}) {
  return request({
    url: '/apis/heroform/getSchemaByName',
    method: 'get',
    params
  })
}

// 查询单个schema
export function findSchema(params = {}) {
  return request({
    url: '/apis/heroform/findSchema',
    method: 'get',
    params
  })
}

// 查询单个schema
export function getBatchLastVersionByName(params = {}) {
  return request({
    url: '/apis/heroform/getBatchLastVersionByName',
    method: 'get',
    params
  })
}
