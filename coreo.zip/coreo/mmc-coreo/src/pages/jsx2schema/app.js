import React from 'react';
import { runApp } from 'ice';
import { ConfigProvider } from '@alifd/next';
import routes from './routes';

const appConfig = {
  app: {
    addProvider: ({ children }) => {
      return <ConfigProvider prefix="next-lstfe-">{children}</ConfigProvider>;
    },
  },
  router: {
    routes,
  },
  icestark: {
    type: 'child',
  },
};

runApp(appConfig);