import * as babylon from "babylon";
import traverse from "babel-traverse";
import * as t from "babel-types";
import generate from "babel-generator";
const convert = require('xml-js');

import {
  stringify, parse,
  unique, getProps, generateOptions,
  getJSXOpeningName, getFieldSchema, getChildSchema,
  Field, Form, Model
} from './utils'

/**
 * 文件解析
 *  */
export function jsxToSchema(code) {
  return JSON.parse(convert.xml2json(code, {compact: false}));
  if (!code) return "{}"

  // 第一步：解析AST
  const ast = babylon.parse(code, {
    sourceType: "module",
    plugins: ["jsx"]
  });

  // 第一model模型
  let model = {
    version: '1.0.0',
    name: '',
    bu: '',
    type: "HERO_FORM_SCHEMA",
    description: '',
    config: {
      deps: [],
    },
    schema: {
      tag: '',
      attr: {},
      child: []
    }
  }

  let isRepeatForm = false

  // 第二步：遍历迭代
  traverse(ast, {
    ImportDeclaration(path, state) {
      const source = path.node.source
      const specifiers = path.node.specifiers

      // 解析出的依赖结构对象
      const dependencie = {}
      let froms = ""

      // 将依赖项解析出来
      if (t.isLiteral(source)) {
        froms = source.value
      }

      // 映射key值：分为两种类型的import值 ImportDefaultSpecifier ImportSpecifier
      const imports = {}
      specifiers.map(spec => {
        const importCode = generate(spec, generateOptions).code

        // 默认写法 例如 import React
        if (t.isImportDefaultSpecifier(spec)) {
          imports['defaultSpecifier'] = importCode
        }

        // 析构写法 例如 import { isEmpty, deepCopy }
        if (t.isImportSpecifier(spec)) {
          if (imports['specifier']) {
            imports['specifier'].push(importCode)
          } else {
            imports['specifier'] = [importCode]
          }
        }

        // 命名空间写法
        if (t.isImportNamespaceSpecifier(spec)) {
          imports['namespaceSpecifier'] = importCode
        }
      })

      // 载入model中
      model.config.deps.push({
        import: imports,
        from: froms
      })
    },

    // 默认解析顺序  export default -> return -> jsxElement
    ExportDefaultDeclaration(path, state) {

      // 向下查找 return 语句
      path.traverse({
        ReturnStatement(path, state) {

          // 再向下查找Form节点
          path.traverse({

            // JSX节点，再过滤Form节点
            JSXElement(path, state) {
              const openingElement = path.node.openingElement
              // 识别出Field属性节点
              if (t.isJSXIdentifier(openingElement.name)) {
                const isFormNode = openingElement.name.name === Form // 如果当前为Form节点
                if (isFormNode) {

                  if (isRepeatForm) {
                    throw new Error("一个页面只识别一个Form表单，若有特殊场景，请考虑创建model引入")
                  }
                  // Form只被识别一次
                  isRepeatForm = true
        
                  model.schema.type = "HeroForm"
        
                  model.schema.tag = Form
                  
                  console.log(`解析JSXElement ${openingElement.name.name}`)
                  model.schema.attr = openingElement.attributes.reduce((pre, attr) => {
                    const propObj = getProps(attr)
                    return { ...pre, ...(propObj || {}) }
                  }, {})

                  // 版本赋值
                  model.version = model.schema.attr.version || '1.0.0'
        
                  // form下所有子节点进行schema序列化
                  model.schema.child = path.node.children.reduce((pre, child) => {
                    const childSchema = getChildSchema(child)
                    if (childSchema) {
                      return [...pre, childSchema]
                    }
                    return pre
                  }, [])
        
                }
              }
            }

          })
        }
      })
    }
  })

  return model
}

/* 只解析model节点 */
export function jsxModel(code) {
  if (!code) return {}

  const entryModels = {}

  // 第一步：解析AST
  const ast = babylon.parse(code, {
    sourceType: "module",
    plugins: ["jsx"]
  });

  traverse(ast, {
    // 默认解析顺序  export default -> return -> jsxElement
    ExportDefaultDeclaration(path, state) {

      // 向下查找 return 语句
      path.traverse({
        ReturnStatement(path, state) {

          // 再向下查找Model节点
          path.traverse({

            // JSX节点，再过滤Model节点
            JSXElement(path, state) {
              const openingElement = path.node.openingElement
              // 识别出Field属性节点
              if (t.isJSXIdentifier(openingElement.name)) {
                const isModelNode = openingElement.name.name === Model
                if (isModelNode) {
                  const modelAttr = openingElement.attributes.reduce((pre, attr) => {
                    const propObj = getProps(attr)
                    return { ...pre, ...(propObj || {}) }
                  }, {})
                  if (!modelAttr.name) return console.error('Model节点必须定义name属性')
                  entryModels[modelAttr.name] = ""
                }
              }
            }
          })
        }
      })
    }
  })

  return entryModels

}
