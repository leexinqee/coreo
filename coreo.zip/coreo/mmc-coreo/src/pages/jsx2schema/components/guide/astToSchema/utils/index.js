import * as t from "babel-types";
import generate from "babel-generator";

// 标签定义
export const Field = 'FormItem' // 标签定义FormItem
export const Form = 'Form' // 标签定义Form
export const Model = 'Model' // 标签定义Model
export const HeroFormSchema = 'heroFormSchema' // 标签定义Form

// 代码生成参数配置
export const generateOptions = {
  compact: true, // 去掉空格
  comments: true, // 去掉注释
  minified: true, // 是否压缩代码
}

// 转义输出到JavaScript端，直接进行JavaScript parse转
function transSpecialChar(str = '') {
  if (str) {
    str = str.replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t")
      .replace(/\\/g, "\\\\")
    }
  return str
}

// 表达式和对象字符串化，便于储存(特殊处理函数表达式等存储方式)
export function stringify(obj, isFormat = false, isNode = true) {
  if(!obj) return
  let stringify = null
  try {
    stringify = JSON.stringify(obj, function(key, value) {
      if (typeof value === "function") {
        return "Function(" + value.toString() + ")";
      }
      return value;
    }, isFormat ? 4 : 0)
  } catch (e) { console.error(e) }

  // typeof window !== 'undefined' 判断是否为node环境
  if (!isNode) {
    stringify = transSpecialChar(stringify)
  }

  return stringify
}

// 表达式解析(解析特殊处理过的函数表达式等存储方式)
export function parse(jsonStr) {
  let parseObject = null
  try {
    parseObject = JSON.parse(jsonStr, function(key, value) {
      if (typeof value === "string" && value.startsWith("Function(") && value.endsWith(")")) {
        value = value.substring(9, value.length - 1);
        return (0, eval)("(" + value + ")");
      }
      return value;
    })
  } catch (e) { console.error(e) }

  return parseObject
}

// 生成unique字符串
export function unique() {
  return Math.random().toString(32).substr(-3) + Date.now().toString(32).substr(-3)
}

// 检查属性节点下，是否还存在jsxElement元素，进行schema虚拟化
export function getAttrNextJsxElement (node) {

  // 如果当前属性是对象属性
  if (t.isObjectExpression(node)) {
    return (node.properties || []).reduce((pre, prop) => {
      const propName = prop.key.name

      // 如果对象属性节点为常规
      if (t.isJSXElement(prop.value)) {  // {addonAfter: <Hello />}
        const nodeSchema = getChildSchema(prop.value)
        return { 
          ...pre,
          [propName]: {
            type: HeroFormSchema,
            ...nodeSchema
          }
        }
      } else {
        try {
          const originCode = (0, eval)(`(${generate(prop.value, generateOptions).code})`)
          return { ...pre, [propName]: originCode }
        } catch (error) {
          throw new Error(`在执行[节点-属性-对象]转换中${propName}存在无法转换的情况，请返回查看`)
        }
      }

    }, {})
  }

}

// 获取节点属性对象
export function getProps(attr) {
  if (!t.isJSXAttribute(attr)) return {}

  const attrName = attr.name.name

  console.log(`当前解析节点属性 ${attrName}`)

  // 如果只有属性名的情况，例如 <Field text />，解析属性应为 {text: true}
  if (!attr.value) return { [attrName]: true }

  // 如果属性类型值为string类型时，直接取属性值返回 例如 <Field type="string" />，解析属性应为 {type: "string"}
  if (t.isLiteral(attr.value)) {
    return { [attrName]: attr.value.value }
  }
  
  // 如果属性值为JSX表达式的时候，直接解析成代码字符串(JSX表达式) 类似这种写法：name={}
  if (t.isJSXExpressionContainer(attr.value)) {
    const container = attr.value
   
    // 如果只是表达式
    if (t.isLiteral(container.expression)) {  // width={123}
      return { [attrName]: container.expression.value }
    }

    // 节点定义模式
    if (t.isIdentifier(container.expression)) {  // component={Input}
      return { [attrName]: container.expression.name }
    }

    // 节点表达式属性
    if (t.isMemberExpression(container.expression)) {  // component={DatePicker.RangPicker}
      return { [attrName]: generate(container.expression, generateOptions).code }
    }


    // 如果属性表达式为JSXElement
    if (t.isJSXElement(container.expression)) {  // component={<Hello />}
      const attrNodeSchema = getChildSchema(container.expression)
      return { 
        [attrName]: {
          type: HeroFormSchema,
          ...attrNodeSchema
        }
      }
    }

    // 属性节点为对象的时候
    if (t.isObjectExpression(container.expression)) { // name={{ hello: 'world' }}
      return { [attrName]: getAttrNextJsxElement(container.expression) }
    }

    // 其他情况按照源码方式解析，如果存在eval识别不了的情况，就提示报错。
    try {
      const originCode = (0, eval)(`(${generate(container.expression, generateOptions).code})`)
      return { [attrName]: originCode }
    } catch (error) {
      throw new Error(`在执行[节点-属性]转换中${attrName}存在无法转换的情况，请返回查看`)
    }

  }
}

// 获取openingName
export function getJSXOpeningName(node) {
  if (!t.isJSXElement(node) || !t.isJSXOpeningElement(node.openingElement)) return ''
  return node.openingElement.name.name
}

// 获取form下的所有描述schema信息
export function getChildSchema (child) {
  // 如果是单独裸露的文本节点
  if (t.isJSXText(child)) {
    // 文本节点，在判断是否有内容文本
    const value = child.value.trim()
    if (!value) return null
    return {
      tag: 'Text',
      attr: { value }
    }
  }

  const openingElement = child.openingElement

  console.log(`当前解析节点 ${getJSXOpeningName(child)}`)

  const childSchema = {
    tag: getJSXOpeningName(child),
    attr: null,
    child: []
  }

  // 当前节点属性
  childSchema.attr = (openingElement.attributes || []).reduce((pre, attr) => {
    const propObj = getProps(attr)
    return { ...pre, ...(propObj || {}) }
  }, {})


  // 子节点
  if(child.children.length) {
    childSchema.child = child.children.reduce((pre, subChild) => {
      const subChildSchema = getChildSchema(subChild)
      if (subChildSchema) {
        return [...pre, subChildSchema]
      }
      return pre
    }, [])
  }

  return childSchema
}
