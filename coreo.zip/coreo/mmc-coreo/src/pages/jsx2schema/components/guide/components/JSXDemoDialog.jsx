import React from 'react'
import { Dialog } from '@alifd/next';

export default function JSXDemoDialog({ visible, onClose }) {
  return (
    <div>
      {/* jsx示例 */}
      <Dialog title="jsx开发示例"
        visible={visible}
        style={{width: 1080, height: 800}}
        footer={false}
        onClose={onClose}
      >
        <div style={{color: 'red'}}>
          <div>不支持的JSX写法：</div>
          <div style={{marginLeft: 10}}>
            1、因解析和作用域问题，暂不支持写法，例如：
            <pre>
            {
              [
              'import React from \'react\'',
              'import Component from \'Component\'',
              'const Component = <Component /> // 不支持',
              'const condition = {} // 不支持',
              'export default function index() {',
              '  const Hello = <FormItem>123</FormItem> // 不支持',
              '  const validator = {} // 不支持',
              '  return (',
              '    <Form validator={validator} condition={condition}>',
              '      <Hello />',
              '      <Component />',
              '    </Form>',
              '  )',
              '}'
              ].join("\n")
            }
            </pre>
            <div>应改写成：</div>
            <pre>
            {
              [
              'import React from \'react\'',
              'import Component from \'Component\'',
              'export default function index() {',
              '  return (',
              '    <Form ',
              '      validator={{"validate": () => {}}}',
              '      condition={{"name": \'\'}}',
              '    >',
              '      <FormItem>123</FormItem>',
              '      <Component />',
              '    </Form>',
              '  )',
              '}'
              ].join("\n")
            }
            </pre>
          </div>

          <h3>正在积极改进中...</h3>
        </div>
      </Dialog>
    </div>
  )
}
