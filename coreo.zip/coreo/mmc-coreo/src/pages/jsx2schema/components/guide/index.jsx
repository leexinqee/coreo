import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { Button, Dialog, Card, Form, Field, Input, Select, Message, Balloon, Tab } from '@alifd/next';
import { isEmpty, debounce } from 'lodash'
import MonacoEditor from 'react-monaco-editor';
import FullScreen from './components/FullScreen'
import JSXDemoDialog from './components/JSXDemoDialog'
import Header from '@/components/Header'
import coreo from '@ali/coreo-core'
import FrameWork from '@/components/FrameWork'

import { urlParse, getEnv } from '../../../../utils'
import { createSchema, getSchemaByName, updateSchema, getBatchLastVersionByName } from '../../apis/heroForm'

import styles from './index.module.scss';


const FormItem = Form.Item;
const formItemLayout = { labelCol: { fixedSpan: 5 }, wrapperCol: { span: 14 } };


const query = urlParse()
const [name, version] = (query.name_version || '').split('|')


class Index extends Component {
  constructor(props) {
    super(props)

    this.isEditor = false
    this.state = {
      initEditor: false,
      jsxCode: ``,
      actionCode: `export default {}`,
      cssCode: "",
      depsCode: '{}',
      status: 1, // 当前状态 1: 草稿 2 保存 3 销毁
      parseModelMap: {}, // 当前model名称对应的正式环境最新版本号
    }

    this.cacheData = {}

    this.callbacks = {}

    this.field = new Field(this)
  }

  componentDidMount() {

    window.onresize = () => {
      const calcWindow = this.recalcWindow()

      this.setState({
        editorHeight: calcWindow.height
      })
    }


    if (query.name_version) {
      // 编辑页面
      // console.log("query.name_version", query.name_version)
      this.isEditor = true
      if (!name) return Message.error("name为必传项")
      let name_version = name
      if (version) name_version = `${name_version}|${version}`

      getSchemaByName({ name_version }).then(res => {
        const { name, version, bu, description, json_schema, action_code, jsx_code, status, schema_type, extra1, css_code, deps } = res.data || {}
        // 缓存数据，提供更新数据缓存
        this.cacheData = res.data || {}

        this.field.setValues({ name, version, bu, description, schema_type, extra1 })

        setTimeout(() => {
          const calcWindow = this.recalcWindow()
          let depsCode = '{}'
          try {
            depsCode = JSON.stringify(JSON.parse(deps), null, 2)
          } catch (error) {}

          this.setState({
            initEditor: true,
            jsxCode: jsx_code || '',
            actionCode: action_code || '',
            cssCode: css_code || '',
            depsCode,
            status,
            editorWidth: calcWindow.width,
            editorHeight: calcWindow.height
          })

          // this.getLastVersion(jsx_code)
        }, 500)
      })
    } else {
      // 异步初始化编辑器，否则构建会出现初始化不成功的情况。
      setTimeout(() => {
        const calcWindow = this.recalcWindow()

        this.setState({
          initEditor: true,
          editorWidth: calcWindow.width,
          editorHeight: calcWindow.height
        })
      }, 500)
    }
  }

  refreshWindow = ({ width = 1024, height = 700 }) => {
    this.setState({ editorWidth: width, editorHeight: height })
  }

  // 监听窗口变化
  recalcWindow = () => {
    const width = document.getElementById("webide-container").clientWidth - 400
    const height = document.documentElement.clientHeight - 120

    return { width, height }
  }

  onChangeHandle = (type = 'jsx', value) => {
    if (type === 'jsx') {
      this.setState({ jsxCode: value })
    } else if (type === 'action') {
      this.setState({ actionCode: value })
    } else if (type === 'css') {
      this.setState({ cssCode: value })
    } else if (type === 'deps') {
      this.setState({ depsCode: value })
    }
  }

  editorDidMountHandle = (editor, monaco) => {
    editor.focus();
  }

  // jsx转Schema
  jsxToSchema = (type, values = {}, ...args) => {
    const { jsxCode, actionCode, cssCode, depsCode } = this.state;
    let model = {};

    this.field.validate([], (a, values) => {
      const errors = this.field.getErrors();
      const err = Object.keys(errors).map(key => errors[key]).filter(v => !!v);

      if (err.length) {
        if (!jsxCode) return Message.error(err[0].join('/'));
      }
      if (!values.description || !values.extra1 || !values.name || !values.schema_type || !values.version) {
        return Message.error('左侧表单内容必填，请检查');
      }
      if (!jsxCode) return Message.error("模板代码不能为空");

      let transformed = '' // JSX转义后的源码或协议
      let tf_action_code = '' // action_code 转义的协议字段
      let tf_css_code = '' // 转换后的css对象描述协议
      let deps = '' // 依赖的json文件
      // console.log("values.schema_type", values.schema_type, String(values.schema_type) === '3')
      if (String(values.schema_type) === '3') {
        // 如果是小程序解析入库
        try {
          const tJsxCode = `export default (${jsxCode})` // 转换必须包裹在export default 函数内，识别入口
          transformed = JSON.stringify(coreo.generateProto(tJsxCode))
          tf_action_code = JSON.stringify(coreo.generateProto(actionCode))
          tf_css_code = JSON.stringify(coreo.styleObjectifier(cssCode))
        } catch (e) {
          console.log(e)
          return Message.error("模板代码不合法, 请检查");
        }
        try {
          deps = JSON.stringify(JSON.parse(depsCode))
        } catch (e) {
          console.log(e)
          return Message.error("依赖文件解析失败");
        }
      } else {
        return throw new Error("暂不支持其他模式")
        /* // 其他模式可直接eval执行源码文件
        try {
          transformed = coreo.transformJSX(jsxCode)
        } catch (e) {
          console.error(e);
          return Message.error("模板代码不合法，必须是合法的xml对象, 请检查");
        } */
      }

      console.log({ values, jsxCode, transformed, actionCode, tf_action_code, cssCode, tf_css_code, deps })

      // 以下是修改前的逻辑
      if (type === 'submit' || type === 'draft') {
        // 1：保存草稿 2：保存入库
        const datas = { ...values, json_schema: transformed, jsx_code: jsxCode || '', action_code: actionCode, status: 1, tf_action_code, css_code: cssCode, tf_css_code, deps };
        // const { name, version } = values;
        const [name, version] = (query.name_version || '').split('|');

        if (this.isEditor && type === 'draft' && datas.version === version) {
          const updateDatas = { ...this.cacheData, ...datas }
          console.log("更新数据的updateDatas：", updateDatas)
          updateSchema(updateDatas).then(res => {
            Message.success(`更新成功`)
          })
          return
        }

        if (type === 'submit') {
          datas.status = 2
        }

        // 如果当前是草稿状态，提交创建发布的时候，草稿态需要删除，因此添加了不可逆删除的草稿ID
        if (this.state.status === 1 && this.cacheData.id) {
          datas.removeDraftId = this.cacheData.id
        }
        
        Dialog.confirm({
          title: '提示',
          content: `请确认是否${type === 'submit' ? '发布' : '保存新草稿'}`,
          onOk: () => {
            createSchema(datas).then((res) => {
              Message.success(`${datas.status === 1 ? '保存草稿' : '入库'}成功，入库ID号:${res.data.id}`)
              setTimeout(() => {
                const env = getEnv()
                if (env === 'daily') {
                  window.location.href = `../jsx2schema/index.html?env=daily#/?name_version=${res.data.name}|${res.data.version}`
                } else {
                  window.location.href = `../jsx2schema/index.html#/?name_version=${res.data.name}|${res.data.version}`
                }
              }, 200)
            })
          },
          onCancel: () => console.log('cancel')
        });
      }
    });
  }

  // name检验器
  nameValidator(rule, value, callback) {
    if (!/^[a-zA-Z]+([_@*&#]*[a-zA-Z0-9]+)*$/.test(value)) {
      callback("名称输入无效，例如：test_ab*12")
    }
  }

  // 编辑器
  jsxEditor = () => {
    const { jsxCode, initEditor, editorWidth = 1024, editorHeight = 700, actionCode, cssCode, depsCode } = this.state
    return (
      <Tab triggerType="click" tabPosition="left" shape="wrapped">
        <Tab.Item key="jsx" title="视图">
          <MonacoEditor
            width="100%"
            height={editorHeight}
            language="html"
            theme="vs-dark"
            value={jsxCode}
            options={{
              selectOnLineNumbers: true,
              renderSideBySide: false,
              tabSize: 2,
              indentSize: 2,
            }}
            onChange={this.onChangeHandle.bind(this, 'jsx')}
            editorDidMount={this.editorDidMountHandle}
          />
        </Tab.Item>
        <Tab.Item key="logic" title="逻辑">
          <MonacoEditor
            width="100%"
            height={editorHeight}
            language="javascript"
            theme="vs-dark"
            value={actionCode}
            options={{
              selectOnLineNumbers: true,
              renderSideBySide: false,
              tabSize: 2,
              indentSize: 2,
            }}
            onChange={this.onChangeHandle.bind(this, 'action')}
          />
        </Tab.Item>
        <Tab.Item key="style" title="样式">
          <MonacoEditor
            width="100%"
            height={editorHeight}
            language="less"
            theme="vs-dark"
            value={cssCode}
            options={{
              selectOnLineNumbers: true,
              renderSideBySide: false,
              tabSize: 2,
              indentSize: 2,
            }}
            onChange={this.onChangeHandle.bind(this, 'css')}
          />
        </Tab.Item>
        <Tab.Item key="deps" title="依赖">
          <MonacoEditor
            width="100%"
            height={editorHeight}
            language="json"
            theme="vs-dark"
            value={depsCode}
            options={{
              selectOnLineNumbers: true,
              renderSideBySide: false,
              tabSize: 2,
              indentSize: 2,
            }}
            onChange={this.onChangeHandle.bind(this, 'deps')}
          />
        </Tab.Item>
      </Tab>
      
    )
  }

  // 渲染webIde页面
  renderWebPage = () => {
    const { initEditor, status, parseModelMap } = this.state
    const init = this.field.init;

    return (
      <FrameWork title={`${this.isEditor ? '更新' : '创建'}组件`} selectKey={1} action={
        <>
          <Button size="large" validate onClick={() => this.jsxToSchema('draft')} style={{ marginRight: 10 }}>保存草稿</Button>
          <Button size="large" validate type="primary" onClick={() => { this.jsxToSchema('submit') }}>确认入库</Button>
        </>
      }>
        <Form {...formItemLayout} field={this.field} className={styles.container}>

          <div className={styles.jsx2schema}>
            <div style={{ width: '100%', display: 'flex', marginRight: '10px' }}>
              <div style={{ width: '200px', marginRight: '10px', paddingRight: 10, borderRight: '1px solid #eee' }}>
                {this.isEditor && (
                  <FormItem label="当前状态">
                    <p className="next-form-text-align">{status === 1 ? '草稿中' : status === 2 ? '已发布' : '已废弃'}</p>
                  </FormItem>
                )}
                <FormItem label="组件名(key)" required requiredMessage="组件名不能为空">
                  <Input placeholder="请输入组件名(key)" {...init('name', {
                    rules: [{ validator: this.nameValidator }]
                  })} name="name" minLength={5} maxLength={30} minmaxLengthMessage="组件名字符数限制在5-30位内" disabled={this.isEditor} />
                </FormItem>
                <FormItem label="应用类型" required requiredMessage="类型不能为空">
                  <Select placeholder="请选择应用类型" name="schema_type" style={{ width: "100%" }} {...init('schema_type')}>
                    {/* <Select.Option value="1">form</Select.Option>
                    <Select.Option value="2">model</Select.Option> */}
                    <Select.Option value="3">小程序(miniapp)</Select.Option>
                  </Select>
                </FormItem>
                <FormItem label="版本号" required requiredMessage="版本号不能为空">
                  <Input placeholder="请输入版本号，例如：1.0.0" name="version" {...init('version', {
                    rules: [{
                      validator(rule, value, callback) {
                        if (!/^([0-9]+)\.([0-9]+)\.([0-9]+)$/.test(value)) {
                          callback("请按规范输入版本号，例如: 1.0.0")
                        }
                      }
                    }]
                  })} />
                </FormItem>
                <FormItem label="领域" required requiredMessage="领域不能为空">
                  <Input placeholder="请输入领域，例如：自营销(market)" name="bu" {...init('bu', {
                    rules: [{
                      validator(rule, value, callback) {
                        if (!/^[a-zA-Z_]{1,}$/.test(value)) {
                          callback("只能输入英文字符/下划线")
                        }
                      }
                    }]
                  })} />
                </FormItem>
                <FormItem label="描述" required>
                  <Input placeholder="请输入描述" name="description" {...init('description')} />
                </FormItem>
                <FormItem label="schemaid">
                  <Input placeholder="schemaid" name="extra1" {...init('extra1')} />
                </FormItem>
              </div>
              {
                <div className={styles.leftWrap} id="webide-container">
                  {this.jsxEditor()}
                </div>
              }
            </div>
          </div>
        </Form>
      </FrameWork>
    )
  }

  render() {
    return this.renderWebPage()
  }
}

export default withRouter(Index)