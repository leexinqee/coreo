import React from 'react';
import Guide from './components/guide';

const Dashboard = () => (
  <Guide />
);

export default Dashboard;
