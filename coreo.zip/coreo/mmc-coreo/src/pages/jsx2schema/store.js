import { createStore } from 'ice';

const store = createStore({});

export default store;
