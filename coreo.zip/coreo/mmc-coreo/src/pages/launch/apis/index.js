import axios from 'axios'
import CsrfToken from '@ali/lst-csrf-token';
import request from '../../../utils/request'

// 创建投放页面
export function create(data = {}) {
  return request({
    url: '/apis/putPage/create',
    method: 'post',
    data
  })
}

// 更新投放页面
export function update(data = {}) {
  return request({
    url: '/apis/putPage/update',
    method: 'post',
    data
  })
}

// 列表查询
export function getList(params = {}) {
  return request({
    url: '/apis/putPage/getList',
    method: 'get',
    params
  })
}

// 查询单个投放页面
export function find(params = {}) {
  return request({
    url: '/apis/putPage/find',
    method: 'get',
    params
  })
}

// 批量获取
export function getSchemaListByType(params = {}) {
  return request({
    url: '/apis/heroform/getBatchByType',
    method: 'get',
    params
  })
}

// 上传OSS
export function uploadData(data = '', name = '') {
  if (!data || !name) return
  let param = new FormData()
  const blobBuffer = new Blob([data]);
  param.append("Filedata", blobBuffer)
  param.append("name", name)
  return axios({
    method: "post",
    url: "https://toolkit.hemayx.cn/upload/coreofile.json",
    withCredentials: true,
    data: param,
    headers: {
      "Content-Type": "multipart/form-data",
      "xsrf-token": CsrfToken.getMmcToken().token || '37d244ea-c9ea-4339-a330-60afce087042'
    },
    type: "json"
  }).then(res => res.data)
}
