import React from 'react';
import { runApp } from 'ice';
import { ConfigProvider } from '@alifd/next';
import routes from './routes';
import store from './store'
const { Provider } = store;

const appConfig = {
  app: {
    addProvider: ({ children }) => {
      return (
        <Provider>
          <ConfigProvider prefix="next-lstfe-">{children}</ConfigProvider>
        </Provider>
      )
    },
  },
  router: {
    routes,
  },
  icestark: {
    type: 'child',
  },
};

runApp(appConfig);