import React, { Component } from 'react'
import { Button, Icon, Form, Input, Select, Message, Search } from '@alifd/next';
import store from '../store';
import styles from './component.module.scss'

const FormItem = Form.Item;

class AsideMenu extends Component {
  constructor(props) {
    super(props)
  }

  componentDidMount() {
    const [state, actions] = this.props.launch
    actions.getSchemaListByType()
  }

  onFormChange = (formValue = {}) => {
    const [state, actions] = this.props.launch
    actions.updateFormValue(formValue)
  }

  versionValidator = (rule, value, callback) => {
    if (!/^([0-9]+)\.([0-9]+)\.([0-9]+)$/.test(value)) {
      callback("请按规范输入版本号，例如: 1.0.0")
    }
  }
  nameValidator = (rule, value, callback) => {
    if (!/^[a-zA-Z]+([_@*&#]*[a-zA-Z0-9]+)*$/.test(value)) {
      callback("名称输入无效，例如：test_ab*12")
    }
  }

  render() {
    const [state, actions] = this.props.launch
    console.log("state", state)
    return (
      <div className={styles.asideShell}>
        <div className={styles.module}>
          <div className={styles.title}>基础信息</div>
          <Form className={styles.content} style={{ padding: 10 }} onChange={this.onFormChange} value={state.formValue} isPreview={this.props.isEdit}>
            <FormItem label="页面" required requiredMessage="请输入页面标识" labelCol={{ fixedSpan: 3 }} minLength={5} maxLength={30} minmaxLengthMessage="页面标识字符数限制在5-30位内" validator={this.nameValidator}>
              <Input placeholder="请输入页面标识" name="app_code" />
            </FormItem>
            <FormItem label="版本号" required requiredMessage="页面版本号不能为空" labelCol={{ fixedSpan: 3 }} validator={this.versionValidator}>
              <Input placeholder="请输入页面版本号，例如：1.0.0" style={{ width: '100%' }} name="version" />
            </FormItem>
          </Form>
        </div>

        <div className={styles.module}>
          <div className={styles.title}>组件库</div>
          <div className={styles.content}>
            <Search shape="simple" placeholder="请输入组件名" className={styles.search} />
            <div className={styles.scrollComponents}>
            {
              state.waitList.map((it, index) => (
                <div key={index} className={styles.item}>
                  <div className={styles.leftCtr}>
                    <img className={styles.protocolImg} src="https://img.alicdn.com/tfs/TB1wpAiOEY1gK0jSZFCXXcwqXXa-42-42.svg" alt="" />
                    <div className={styles.textWrapper}>
                      <span className={styles.moduleTitle}>{it.name}</span>
                      <span className={styles.moduleKey}>{it.description}</span>
                    </div>
                  </div>
                  <div className={styles.rightCtr}>
                    <span>{it.version}</span>
                    <span className={styles.icon} onClick={() => {
                      actions.updateSelected({ type: 'add', id: it.id })
                    }}>
                      <Icon type="add" size='xxs' style={{ color: "#fff" }} />
                    </span>
                  </div>
                </div>
              ))
            }
            </div>

          </div>
        </div>
      </div>
    )
  }
}

export default store.withModel("launch")(AsideMenu)
