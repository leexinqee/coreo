import React from 'react'
import { withRouter } from 'react-router-dom'
import moment from 'moment'
import { Button } from '@alifd/next'
import styles from './component.module.scss'
import { STATUS_MAP } from '../constants'

function ModelCard(props = {}) {

  const time = props.gmt_modified ? moment(props.gmt_modified).format("YYYY-MM-DD hh:mm:ss") : ''

  const { name, version } = props

  return (
    <div className={styles.model_card}>
      <div className={styles.model_title_wrap}>
        <span className={styles.model_name}>{props.name}</span>
        <span className={styles.model_version}>{props.version}</span>
      </div>
      <div className={styles.model_body}>
        <div className={styles.model_body_desc}>{props.description}</div>
        <div className={styles.model_body_foot}>
          <span className={styles.model_body_bu}>{props.bu}</span>
          <span className={styles.model_body_bu} style={{fontWeight: 'bold'}}>{STATUS_MAP[String(props.status)]}</span>
        </div>
      </div>
    </div>
  )
}

export default withRouter(ModelCard)
