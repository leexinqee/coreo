import React, { Component } from 'react'
import { Transfer, Message } from '@alifd/next';
import { getSchemaListByType } from '../apis'
import styles from './component.module.scss'

let change = false
export default class SelectArea extends Component {
  constructor(props) {
    super(props)
    this.state = {
      itemSource: [],
      selectedIds: []
    }
    this.cacheData = []
  }

  componentDidMount() {
    this.getPublishComponentList()
  }

  getSelectedValue = (source, components) => {
    if (!source || !components) return null
    return components.map(c => source.find(s => s.label === c.n && s.version === c.v)).map(c => c.value)
  }  

  static getDerivedStateFromProps(nextProps, prevState) {
    if (change) return null
    if (!prevState.itemSource || !nextProps.components || !prevState.itemSource.length || !nextProps.components.length) return null
    const selectedItems = nextProps.components.map(c => prevState.itemSource.find(s => s.label === c.n && s.version === c.v))
    console.log('2222222', nextProps.components, prevState.itemSource, selectedItems)
    const selectedIds = selectedItems.filter(i => !!i).map(c => c.value)
    return { selectedIds }
  }

  getPublishComponentList = () => {
    getSchemaListByType({
      page: 1,
      pageSize: 10000,
      status: 2,
      schema_type: 3
    }).then(res => {
      if (res.data && res.data.length) {
        const itemSource = res.data.filter(i => (i.json_schema && i.tf_action_code)).map(i => ({
          label: i.name,
          value: i.id,
          version: i.version,
          description: i.description
        }))
        this.cacheData = res.data
        this.setState({ itemSource })
      }
    })
  }

  handleChange = (selectedIds) => {
    change = true
    this.setState({ selectedIds })
    if (selectedIds.length) {
      const selectedItems = selectedIds.map(id => this.cacheData.find(item => item.id === id))
      const itemMap = { c: [] }
      const components = []
      selectedItems.map(item => {
        itemMap.c.push({
          j: JSON.parse(item.json_schema || '{}'),
          a: JSON.parse(item.tf_action_code || '{}'),
          n: item.name,
          v: item.version
        })
        components.push({
          n: item.name,
          v: item.version
        })
      })
      this.props.selectChange(itemMap, components)
    }
  }

  itemRender = (data) => {
    return (
      <div className={styles.itemContainer}>
        <span className={styles.labelContainer}>
          <span className={styles.label}>{data.label}</span>
          <span className={styles.version}>{data.version}</span>
        </span>
        <span className={styles.description}>{data.description}</span>
      </div>
    )
  }

  
  render() {
    const { itemSource, selectedIds } = this.state
    // const selectedValue = this.getSelectedValue(itemSource, selectedComponents)
    // console.log("selectedValue", selectedValue)
    
    return (
      <div className={styles.selectArea}>
        <Transfer
          showSearch
          value={selectedIds}
          dataSource={itemSource}
          itemRender={this.itemRender}
          defaultLeftChecked={[]}
          onChange={this.handleChange}
          titles={["请选择投放的组件", "将要投放的组件"]}
        />
      </div>
    )
  }
}
