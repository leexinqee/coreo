import React, { Component } from 'react'
import { Transfer, Message, Icon } from '@alifd/next';
import store from '../store';
import { getSchemaListByType } from '../apis'
import './selectArea.scss'

let change = false
// const [state, actions] = store.useModel('foo');
class SelectArea extends Component {
  constructor(props) {
    super(props)
    this.state = {
      itemSource: [],
      selectedIds: []
    }
    this.cacheData = []
  }

  componentDidMount() {
  }


  render() {
    const { itemSource, selectedIds } = this.state
    const [state, actions] = this.props.launch
    
    return (
      <div className="selectArea">
        <div className="struct-fragment">
          <div className="struct-fragment-title">页面组件</div>
          
          {
            state.selectedList.length > 0 ?
            state.selectedList.map((i, index) => (
              <div key={index} className="struct-module-item">
                <div className="struct-item-left">
                  <div className="icon-wrapper">
                    <img src="https://img.alicdn.com/tfs/TB17hMsOBr0gK0jSZFnXXbRRXXa-26-26.svg" alt="" />
                  </div>
                  <div className="struct-item-tag">
                    {i.name}
                    <span className="item-plain"> ({i.version}) </span>
                    {
                      state.newVersionMap[i.name] && (
                        <span className="item-plain item-tips">有新版本{state.newVersionMap[i.name]}</span>
                      )
                    }
                  </div>
                </div>
                <div className="struct-item-right" onClick={() => {
                  actions.updateSelected({ type: 'remove', id: i.id })
                }}>
                  <Icon className="delete-icon" type="delete-filling" size="small" />
                </div>
              </div>
            )) :
            <div className="overlay-empty">请添加组件</div>
          }

        </div>
      </div>
    )
  }
}

export default store.withModel("launch")(SelectArea)