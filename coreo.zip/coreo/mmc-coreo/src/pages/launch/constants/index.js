export const STATUS_MAP = {
  '1': '草稿中',
  '2': '已发布',
  '3': '已废弃',
}

// APP通道配置
export const CHANNEL = {
  INDEX_CUSTOMIZED_CONFIG: {
    app_code: 'INDEX_CUSTOMIZED_CONFIG', // 对应消费端MTOP下发资源搜索的flowEntry字段
    module_id: '28612670011', // 模块ID，配置端添加素材的ID信息
    resource_id: '848361742114'
  }
}