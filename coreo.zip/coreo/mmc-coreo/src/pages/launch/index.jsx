import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { Button, Dialog, Card, Form, Field, Input, Select, Message, Balloon, Icon } from '@alifd/next';
import { isEmpty, debounce } from 'lodash'
import coreo from '@ali/coreo-core'
import { urlParse, getEnv } from '@/utils'
import store from './store';
import SelectArea from './components/SelectArea'
import AsideMenu from './components/AsideMenu'
import { uploadData, create, update, find } from './apis'
import Header from '@/components/Header'
import FrameWork from '@/components/FrameWork'

import styles from './index.module.scss';

const FormItem = Form.Item;

const env = getEnv()
const query = urlParse()
const isEdit = !!query.id

class Index extends Component {
  constructor(props) {
    super(props)

    this.state = {
      components: null
    }
    this.putData = null
    this.selectComponents = null
  }

  componentDidMount() {
    const [state, actions] = this.props.launch
    if (isEdit) {
      find({ id: query.id }).then(res => {
        console.log('res', res)
        const { app_code, version, components } = res.data || {}
        actions.setEditData({ app_code, version, components })
      })
    }
  }

  // 投放页面
  putPage = async (environment = 'pre') => {
    const [state, actions] = this.props.launch
    const { app_code, version } = state.formValue
    if (!app_code || !version) {
      return Message.error("请完善基础信息")
    }
    // if (!state.selectedList.length) {
    //   return Message.error("请添加需要投放的组件")
    // }

    // 继续下一步执行
    const continueNext = async () => {
      const itemMap = state.selectedList.length > 0 ? {
        // 页面投放组件列表
        p: state.selectedList.map(item => ({
          j: JSON.parse(item.json_schema || '{}'),
          a: JSON.parse(item.tf_action_code || '{}'),
          s: JSON.parse(item.tf_css_code || '{}'),
          d: JSON.parse(item.deps || '{}'),
          n: item.name,
          v: item.version
        })),
        // 页面将投放的组件所有依赖
        c: []
      } : { p: [], c: [] }
  
      // 将投放组件内容上传至OSS
      console.log("投放数据：", itemMap)
      const oss_url = await this.uploadDataToOss({
        data: JSON.stringify(itemMap),
        name: `${environment}-${app_code}-${version}.json`
      })

      if (!oss_url) return

      // 创建投放页面数据到数据库
      const storeData = {
        app_code, // 页面名称
        module_id: '',
        resource_id: '',
        version,
        components: JSON.stringify(state.selectedList),
      }

      if (environment === 'pre') {
        storeData.pre_oss_url = oss_url
      } else if (environment === 'prod') {
        storeData.oss_url = oss_url
      }
      // console.log("入库数据：", storeData)
      
      if (isEdit) {
        storeData.id = query.id
        await update(storeData).then(res => {
          Message.success("投放页面已更新")
          window.location.reload()
        })
      } else {
        await create(storeData).then(res => {
          Message.success("投放页面已入库保存")
          this.goEditPage(res.data.id)
        })
      }
    }

    if (isEdit) {
      Dialog.confirm({
        title: '更新提示',
        content: `更新页面投放，将替换原有OSS内容，请确认继续操作？`,
        onOk: () => {
          continueNext()
        },
        onCancel: () => console.log('cancel')
      })
    } else {
      continueNext()
    }
  }

  goEditPage = (id) => {
    if (env === 'daily') {
      window.location.href = `../launch/index.html?env=daily#/?id=${id}`
    } else {
      window.location.href = `../launch/index.html#/?id=${id}`
    }
  }

  // 数据上传OSS
  uploadDataToOss = async ({ data, name }) => {
    if (!name || !data) return Message.error("上传的数据或文件名称不能为空")
    if (!name.endsWith('.json')) return Message.error("文件命名以为.json命名")

    return await uploadData(data, name).then(async res => {
      if (res.result) {
        return res.result
      } else {
        Message.error("数据上传OSS失败")
      }
    }).catch(e => {
      Message.error("数据上传OSS失败");
      Dialog.confirm({
        title: '登录授权提示',
        content: `请前往盒马集市平台登录授权`,
        onOk: () => {
          window.open("https://portal.hemayx.cn/", "_blank");
        },
        onCancel: () => console.log('cancel')
      })
      console.log('err', e)
      return false
    })
  }


  // 渲染webIde页面
  renderWebPage = () => {
    const { components } = this.state

    return (
      <FrameWork title='页面投放' selectKey={2} action={
        <>
          <Button size="large" type="primary" onClick={this.putPage.bind(this, 'pre')}>{isEdit ? '预发更新' : '预发创建'}</Button>
          <Button size="large" type="primary" warning onClick={this.putPage.bind(this, 'prod')} style={{marginLeft: 10}}>{isEdit ? '线上更新' : '线上创建'}</Button>
        </>
      }>
        <div className={styles.container}>
          <div className={styles.content}>
            <AsideMenu isEdit={isEdit} />
            <SelectArea />
          </div>
        </div>
      </FrameWork>
    )
  }

  render() {
    return this.renderWebPage()
  }
}

export default store.withModel("launch")(withRouter(Index))