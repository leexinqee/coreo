import { Message } from '@alifd/next';
import { getSchemaListByType } from './apis'

export default {
  // 定义 model 的初始 state
  state: {
    waitList: [],  // 待选列表
    selectedList: [],  // 已选列表
    formValue: {},  // 基础信息表单
    newVersionMap: {}, // 是否存在新的版本map
  },

  // 定义改变该模型状态的纯函数
  reducers: {
    update(prevState, payload) {
      return {
        ...prevState,
        ...payload,
      };
    },
    addSelected(prevState, id) {
      const { json_schema, tf_action_code, tf_css_code, deps, name, version } = prevState.waitList.find(i => i.id === id)
      prevState.selectedList.push({ json_schema, tf_action_code, tf_css_code, deps, name, version })
      // 状态检测
      prevState.selectedList.map(s => {
        if (s.name === name) {
          if (version != s.version) {
            prevState.newVersionMap[s.name] = version
          } else {
            prevState.newVersionMap[s.name] = false
          }
        }
      })
    },
    removeSelected(prevState, id) {
      const index = prevState.selectedList.findIndex(i => i.id === id)
      prevState.selectedList.splice(index, 1)
    },
    updateFormValue(preState, formValue) {
      preState.formValue = formValue
    },
    updateSelectedList(preState, selectedList) {
      preState.selectedList = selectedList
    },
    // 检验新的版本号
    checkSelectListHasNewVersion(preState) {
      if (preState.selectedList.length && preState.waitList.length) {
        preState.selectedList.map(s => {
          const current = preState.waitList.find(w => w.name === s.name)
          if (current.version != s.version) {
            preState.newVersionMap[s.name] = current.version
          } else {
            preState.newVersionMap[s.name] = false
          }
        })
      }
    }
  },

  // 定义处理该模型副作用的函数
  effects: ({ launch }) => ({
    // 获取备选组件列表
    getSchemaListByType() {
      getSchemaListByType({
        page: 1,
        pageSize: 10000,
        status: 2,
        schema_type: 3
      }).then(res => {
        if (res.data && res.data.length) {
          this.setState({ waitList: res.data.filter(i => (i.json_schema && i.tf_action_code)) })
          launch.checkSelectListHasNewVersion()
        }
      })
    },
    // 添加/删除投放组件
    updateSelected({ type, id }) {
      if (type === 'add') launch.addSelected(id)
      if (type === 'remove') launch.removeSelected(id)
    },
    // 编辑状态下，获取到的components信息
    setEditData({ app_code, version, components }) {
      try {
        const selectedList = JSON.parse(components)
        launch.updateFormValue({
          app_code, version
        })
        launch.updateSelectedList(selectedList)
        launch.checkSelectListHasNewVersion()
      } catch (e) {
        console.log( e)
      }
    }
  })
};