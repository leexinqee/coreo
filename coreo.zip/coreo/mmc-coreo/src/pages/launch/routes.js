import Dashboard from './index';

export default [
  { path: '/', exact: true, component: Dashboard }
];
