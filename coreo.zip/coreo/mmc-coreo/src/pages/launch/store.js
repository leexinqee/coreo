import { createStore } from 'ice';
import launch from './models';

const store = createStore({ launch });

export default store;
