import React from 'react'
import { withRouter } from 'react-router-dom'
import moment from 'moment'
import { Button } from '@alifd/next'
import styles from './component.module.scss'
import { STATUS_MAP } from '../constants'
import { getEnv } from '@/utils'

function ModelCard(props = {}) {

  const time = props.gmt_modified ? moment(props.gmt_modified).format("YYYY-MM-DD hh:mm:ss") : ''

  const { name, version } = props

  const goEdit = ({ name, version }) => {
    const env = getEnv()
    if (env === 'daily') {
      window.location.href = `../jsx2schema/index.html?env=daily#/?name_version=${name}|${version}`
    } else {
      window.location.href = `../jsx2schema/index.html#/?name_version=${name}|${version}`
    }
  }

  return (
    <div className={styles.model_card}>
      <div className={styles.model_title_wrap}>
        <span className={styles.model_name}>{props.name}</span>
        <span className={styles.model_version}>{props.version}</span>
      </div>
      <div className={styles.model_body}>
        <div className={styles.model_body_desc}>{props.description}</div>
        <div className={styles.model_body_foot}>
          <span className={styles.model_body_bu}>{props.bu}</span>
          <span className={styles.model_body_bu} style={{fontWeight: 'bold'}}>{STATUS_MAP[String(props.status)]}</span>
        </div>
        <div className={styles.model_body_foot}>
          <span>{time}</span>
          <Button text type="primary" target="_blank" component="a" onClick={goEdit.bind(null, { name, version })}>编辑</Button>
        </div>
      </div>
    </div>
  )
}

export default withRouter(ModelCard)
