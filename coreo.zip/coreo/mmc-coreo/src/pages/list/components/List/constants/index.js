// 类型
export const SCHEMA_TYPE_MAP = {
  '1': '表单(form)',
  '2': '模型(model)',
  '3': '小程序(miniapp)',
}

// 状态
export const STATUS_MAP = {
  '1': '草稿中',
  '2': '已发布',
  '3': '已废弃',
}


// 查询配置项
export const LIST_SEARCH_CONFIG = [
  {
    label: '名称',
    labelWidth: 2,
    component: 'Input',
    componentProps: {
      placeholder: '请输入名称'
    },
    formBinderProps: {
      name: 'name'
    }
  },
  {
    label: '版本',
    labelWidth: 2,
    component: 'Input',
    componentProps: {
      placeholder: '请输入版本'
    },
    formBinderProps: {
      name: 'version'
    }
  },
  {
    label: '状态',
    labelWidth: 2,
    component: 'Select',
    componentProps: {
      placeholder: '请选择状态',
      dataSource: [
        { label: '草稿中', value: '1' },
        { label: '已发布', value: '2' },
      ]
    },
    formBinderProps: {
      name: 'status'
    }
  },
  {
    label: '查询',
    type: 'primary',
    component: 'Button'
  }
]


