import React, { Component } from 'react'
import { Table, Button, Pagination, Tab, Icon } from '@alifd/next';
import { getSchemaList } from '../../apis/heroForm'
import Pannel from './components/Panel'
import ModelCard from './components/ModelCard'
import Model from './components/Model'
import FormTable from './components/FormTable'
import SearchField from '@/components/SearchField'
import Header from '@/components/Header'
import FrameWork from '@/components/FrameWork'
import { LIST_SEARCH_CONFIG, SCHEMA_TYPE_MAP, STATUS_MAP } from './constants'
import styles from './index.module.scss'

export default class List extends Component {

  constructor(props) {
    super(props)

    this.state = {}
  }

  componentDidMount() {}

  goCreate = () => {
    window.location.href = '../'
  }

  render() {
    
    return (
      <FrameWork title='组件管理' selectKey={1}>
        <div className={styles.container}>
          
          <div className={styles.content}>
            <Button type="primary" component="a" href="../jsx2schema/index.html"><Icon type="add" />创建组件</Button>
            <Model type={3}/>
          </div>
          
        </div>
      </FrameWork>
    )
  }
}
