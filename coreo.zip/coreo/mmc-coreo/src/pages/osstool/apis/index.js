import axios from 'axios'
import CsrfToken from '@ali/lst-csrf-token';


// 上传OSS
export function uploadData(data = '', name = '') {
  if (!data || !name) return
  let param = new FormData()
  const blobBuffer = new Blob([data]);
  param.append("Filedata", blobBuffer)
  param.append("name", name)
  return axios({
    method: "post",
    url: "https://toolkit.hemayx.cn/upload/coreofile.json",
    withCredentials: true,
    data: param,
    headers: {
      "Content-Type": "multipart/form-data",
      "xsrf-token": CsrfToken.getMmcToken().token || 'a59863ca-5225-4ecb-9ff4-bcb42f8a16c7'
    },
    type: "json"
  }).then(res => res.data)
}

// 获取上传OSS数据
export function getData(url = '') {
  return axios({
    method: "get",
    url,
    // withCredentials: true,
    headers: {
      "Content-Type": " "
    },
  }).then(res => res)
}
