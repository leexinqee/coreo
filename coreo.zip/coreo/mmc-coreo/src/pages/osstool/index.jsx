import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { Button, Dialog, Card, Form, Field, Input, Select, Message, Balloon, Icon } from '@alifd/next';
import { isEmpty, debounce } from 'lodash'
import { urlParse, getEnv } from '@/utils'
import FrameWork from '@/components/FrameWork'
import { uploadData, getData } from './apis'
import Header from '@/components/Header'
import styles from './index.module.scss';

const FormItem = Form.Item;

const query = urlParse()
// let queryUrl = query.url || ''
// if (queryUrl) queryUrl = decodeURIComponent(queryUrl)
let key = query.key || ''

class Index extends Component {
  constructor(props) {
    super(props)

    this.state = {
      pre: '',
      prod: '',
      formValue: {
        ossValue: ``
      }
    }
  }

  componentDidMount() {}

  // 投放页面
  putPage = async (environment = 'pre') => {
    const { ossValue = '' } = this.state.formValue
    if (!ossValue) return Message.error("上传数据不能为空")
    let reOssValue = ''
    try {
      reOssValue = JSON.stringify(JSON.parse(ossValue))
    } catch (error) {
      return Message.error("JSON数据格式不正确")
    }

    // 上传OSS内容
    const uniKey = key ? key : `file-${Date.now().toString(36)}`
    await this.uploadDataToOss({
      data: reOssValue,
      name: `${environment}-${uniKey}.json`
    }).then((url) => {
      Message.success("上传成功")
      this.setState({
        [environment]: url
      })
    })
  }


  // 数据上传OSS
  uploadDataToOss = async ({ data, name }) => {
    if (!name || !data) return Message.error("上传的数据或文件名称不能为空")
    if (!name.endsWith('.json')) return Message.error("文件命名以为.json命名")

    return await uploadData(data, name).then(async res => {
      if (res.result) {
        return res.result
      } else {
        Message.error("数据上传OSS失败")
      }
    }).catch(e => {
      Message.error("数据上传OSS失败");
      Dialog.confirm({
        title: '登录授权提示',
        content: `请前往盒马集市平台登录授权`,
        onOk: () => {
          window.open("https://portal.hemayx.cn/", "_blank");
        },
        onCancel: () => console.log('cancel')
      })
      console.log('err', e)
      return false
    })
  }

  onFormChange = (formValue = {}) => {
    this.setState({ formValue })
  }

  // 渲染webIde页面
  renderWebPage = () => {
    const { pre, prod } = this.state
    return (
      <FrameWork title='OSS小工具' selectKey={3}>
        <div className={styles.container}>
          <div className={styles.content}>
            <Form onChange={this.onFormChange} value={this.state.formValue}>
              <FormItem label="OSS值" required requiredMessage="请输入OSS值(JSON格式)" labelCol={{ fixedSpan: 3 }}>
                <Input.TextArea placeholder="请输入OSS值(JSON格式)" name="ossValue" autoHeight={{ minRows: 3, maxRows: 10 }}/>
              </FormItem>
              <FormItem style={{marginLeft: 60}}>
                {pre && ( <div>预发链接：{pre}</div> )}
                {prod && ( <div>线上链接：{prod}</div> )}
              </FormItem>
              <FormItem style={{marginLeft: 60}}>
                <Button size="large" type="primary" onClick={this.putPage.bind(this, 'pre')} style={{marginRight: 10}}>发布预发</Button>
                <Button size="large" type="primary" warning onClick={this.putPage.bind(this, 'prod')}>发布线上</Button>
              </FormItem>
            </Form>
          </div>
        </div>
      </FrameWork>
    )
  }

  render() {
    return this.renderWebPage()
  }
}

export default Index