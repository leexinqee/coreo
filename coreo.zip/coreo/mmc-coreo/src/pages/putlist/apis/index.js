import axios from 'axios'
import CsrfToken from '@ali/lst-csrf-token';
import request from '../../../utils/request'

// 创建投放页面
export function create(data = {}) {
  return request({
    url: '/apis/putPage/create',
    method: 'post',
    data
  })
}

// 更新投放页面
export function update(data = {}) {
  return request({
    url: '/apis/putPage/update',
    method: 'post',
    data
  })
}

// 列表查询
export function getList(params = {}) {
  return request({
    url: '/apis/putPage/getList',
    method: 'get',
    params
  })
}

// 查询单个投放页面
export function find(params = {}) {
  return request({
    url: '/apis/putPage/find',
    method: 'get',
    params
  })
}

// 批量获取
export function getSchemaListByType(params = {}) {
  return request({
    url: '/apis/heroform/getBatchByType',
    method: 'get',
    params
  })
}