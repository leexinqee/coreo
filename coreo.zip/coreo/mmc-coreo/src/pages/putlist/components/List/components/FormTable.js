import React, { Component } from 'react'
import { Table, Button, Tab } from '@alifd/next';
import { withRouter } from 'react-router-dom'
import { getSchemaList } from '../../../apis/heroForm'

import Pannel from './Panel'
import ModelCard from './ModelCard'
import SearchField from '@/components/SearchField'
import Pagination from '@/components/Pagination'

import { LIST_SEARCH_CONFIG, SCHEMA_TYPE_MAP, STATUS_MAP } from '../constants'

class FormTable extends Component {

  constructor(props) {
    super(props)

    this.state = {
      listData: [],
      page: 1,
      total: 0,
      search: {
        config: LIST_SEARCH_CONFIG,
        value: {}
      }
    }
  }

  componentDidMount() {
    this.getSchemaList()
  }

  getSchemaList = (params = {}) => {
    const { page } = this.state
    getSchemaList({ ...params, page, schema_type: 1 }).then(res => {
      console.log("res", res)
      this.setState({
        listData: res.data || [],
        total: res.total || res.data.length
      })
    })
  }

  onPageChange = (current) => {
    this.setState({ page: current }, () => {
      this.getSchemaList()
    })
  }

  onSearch = (values) => {
    this.getSchemaList(values)
  }

  goEdit = (record) => {
    // this.props.history.push(`/?name_version=${record.name}|${record.version}`)
    window.location.href = `../jsx2schema/index.html#/?name_version=${record.name}|${record.version}`
  }

  render() {
    const { listData, search, total } = this.state

    return (
      <div style={{ paddingTop: 20 }}>
        <SearchField config={search.config} value={search.value} search={this.onSearch} />

        <Table dataSource={listData} hasBorder={false}>
          <Table.Column title="名称" dataIndex="name" />
          <Table.Column title="版本" dataIndex="version" />
          <Table.Column title="领域" dataIndex="bu" />
          <Table.Column title="应用类型" dataIndex="schema_type" cell={v => SCHEMA_TYPE_MAP[String(v)]} />
          <Table.Column title="状态" dataIndex="status" cell={v => STATUS_MAP[String(v)]} />
          <Table.Column title="描述" dataIndex="description" />
          <Table.Column title="操作" cell={(value, index, record) => (
            <Button text type="primary" target="_blank" component="a" href={`../jsx2schema/index.html#/?name_version=${record.name}|${record.version}`}>编辑</Button>
          )} />
        </Table>

        <Pagination page={this.state.page} total={total} onChange={this.onPageChange} />
      </div>
    )
  }
}

export default withRouter(FormTable)