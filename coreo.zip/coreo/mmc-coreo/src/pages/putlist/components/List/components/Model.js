import React, { Component } from 'react'
import { Table, Button, Tab } from '@alifd/next';
import { getList } from '../../../apis'

import ModelCard from './ModelCard'
import SearchField from '@/components/SearchField'
import Pagination from '@/components/Pagination'
import Empty from '@/components/Empty'

import { LIST_SEARCH_CONFIG, SCHEMA_TYPE_MAP, STATUS_MAP } from '../constants'

export default class Model extends Component {

  constructor(props) {
    super(props)

    this.state = {
      listData: [],
      page: 1,
      total: 0,
      search: {
        config: LIST_SEARCH_CONFIG,
        value: {}
      }
    }
  }

  componentDidMount() {
    this.getSchemaList()
  }

  getSchemaList = (params = {}) => {
    const { type = 3 } = this.props;
    const { page } = this.state
    getList({ ...params, page }).then(res => {
      this.setState({
        listData: res.data || [],
        total: res.total || res.data.length
      })
    })
  }

  onPageChange = (current) => {
    this.setState({ page: current }, () => {
      this.getSchemaList()
    })
  }

  onSearch = (values) => {
    this.getSchemaList(values)
  }

  render() {
    const { listData, search, total } = this.state

    return (
      <div style={{ paddingTop: 20 }}>
        <SearchField config={search.config} value={search.value} search={this.onSearch} />
        <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {
          listData.length ? (
            listData.map((item, index) => (
              <ModelCard key={index} {...item} />
            ))
          ) : (
            <Empty />
          )
        }
        </div>

        <Pagination page={this.state.page} onChange={this.onPageChange} total={total} />
      </div>
    )
  }
}
