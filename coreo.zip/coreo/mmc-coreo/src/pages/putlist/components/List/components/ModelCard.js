import React from 'react'
import { withRouter } from 'react-router-dom'
import moment from 'moment'
import { Button } from '@alifd/next'
import styles from './component.module.scss'
import { getEnv, copyToClipboard } from '@/utils'

function ModelCard(props = {}) {

  const time = props.gmt_modified ? moment(props.gmt_modified).format("YYYY-MM-DD HH:mm:ss") : ''
  const { id } = props

  const goEdit = (id) => {
    const env = getEnv()
    if (env === 'daily') {
      window.location.href = `../launch/index.html?env=daily#/?id=${id}`
    } else {
      window.location.href = `../launch/index.html?id=${id}`
    }
  }

  return (
    <div className={styles.model_card}>
      <div className={styles.model_title_wrap}>
        <span className={styles.model_name}>{props.app_code}</span>
        <span className={styles.model_version}>{props.version}</span>
      </div>
      <div className={styles.model_body}>
        {/* <div className={styles.model_body_desc}>资源路径: <span style={{color: 'orange'}}>{props.oss_url}</span></div> */}
        <div className={styles.model_body_foot}>
          {
            props.pre_oss_url ? (
              <Button type="primary" text size="large" onClick={copyToClipboard.bind(null, props.pre_oss_url)}>资源投放链接(点击复制)</Button>
            ) : '-'
          }
          <span className={styles.model_body_bu} style={{fontWeight: 'bold'}}>预发</span>
        </div>
        <div className={styles.model_body_foot}>
          {
            props.oss_url ? (
              <Button type="primary" text size="large" onClick={copyToClipboard.bind(null, props.oss_url)}>资源投放链接(点击复制)</Button>
            ) : '-'
          }
          <span className={styles.model_body_bu} style={{fontWeight: 'bold'}}>线上</span>
        </div>
        <div className={styles.model_body_foot}>
          <span>{time}</span>
          <Button text type="primary" target="_blank" component="a" onClick={goEdit.bind(null, id)}>编辑</Button>
        </div>
      </div>
    </div>
  )
}

export default withRouter(ModelCard)
