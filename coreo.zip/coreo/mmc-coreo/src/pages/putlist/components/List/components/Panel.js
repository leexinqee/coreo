import React from 'react'
import styles from './component.module.scss'

export default function Panel({ title, children }) {
  return (
    <div className={styles.list__pannel}>
      <div className={styles.pannel_title}>{title}</div>
      <div className={styles.pannel_body}>{children}</div>
    </div>
  )
}
