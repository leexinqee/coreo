// 类型
export const SCHEMA_TYPE_MAP = {
  '1': '表单(form)',
  '2': '模型(model)',
  '3': '小程序(miniapp)',
}

// 状态
export const STATUS_MAP = {
  '1': '草稿中',
  '2': '已发布',
  '3': '已废弃',
}

// 查询配置项
export const LIST_SEARCH_CONFIG = [
  {
    label: '页面',
    labelWidth: 2,
    component: 'Input',
    componentProps: {
      placeholder: '请输入PageKey',
    },
    formBinderProps: {
      name: 'app_code'
    }
  },
  {
    label: '版本',
    labelWidth: 2,
    component: 'Input',
    componentProps: {
      placeholder: '请输入版本'
    },
    formBinderProps: {
      name: 'version'
    }
  },
  {
    label: '查询',
    type: 'primary',
    component: 'Button'
  }
]


