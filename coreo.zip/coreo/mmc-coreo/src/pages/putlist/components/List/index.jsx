import React, { Component } from 'react'
import { Table, Button, Pagination, Tab, Icon } from '@alifd/next';
import Model from './components/Model'
import SearchField from '@/components/SearchField'
import Header from '@/components/Header'
import styles from './index.module.scss'
import FrameWork from '@/components/FrameWork'
export default class List extends Component {
  constructor(props) {
    super(props)

    this.state = {}
  }

  componentDidMount() {}

  goCreate = () => {
    window.location.href = '../'
  }

  render() {
    return (
      <FrameWork title='页面管理' selectKey={2}>
        <div className={styles.container}>
          <div className={styles.content}>
            <Button type="primary" component="a" href="../launch/index.html"><Icon type="add" />页面投放</Button>
            <Model/>
          </div>
        </div>
      </FrameWork>
    )
  }
}
