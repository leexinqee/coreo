import List from './components/List';

export default [
  { path: '/', exact: true, component: List }
];
