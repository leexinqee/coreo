import { Message } from '@alifd/next'

// url参数解析
const parseUrl = (url = window.location.search) => {
  let obj = {},
    index = url.indexOf('?'),
    params = url.substr(index + 1);

  if (index != -1) {
    let parr = params.split('&');
    for (let i of parr) {
      let arr = i.split('=');
      obj[arr[0]] = arr[1];
    }
  }
  return obj;
}

export function urlParse() {
  const searchObj = parseUrl()
  const hashObj = parseUrl(window.location.hash)
  return { ...searchObj, ...hashObj }
}

// 防抖函数

export function debounce(func, delay = 200) {
  let timer
  return function (...args) {
    return new Promise((resolve, reject) => {
      if (timer) {
        clearTimeout(timer)
      }
      timer = setTimeout(() => {
        resolve(func.apply(this, args))
      }, delay)
    })
  }
}

// 获取环境变量
export function getEnv() {
  const query = urlParse()
  // 如果查询参数有环境标识符
  if (query.env) {
    return ['daily', 'pre', 'prod'].includes(query.env) ? query.env : 'prod'
  } else {
    const hostname = window.location.hostname
    if (hostname === '127.0.0.1' || hostname === 'localhost') return 'daily'
    if (hostname.startsWith('pre-')) return 'pre'
    return 'prod'
  }
}

// 复制函数
export function copyToClipboard(text) {
  var textArea = document.createElement("textarea");
  textArea.style.position = 'fixed';
  textArea.style.top = '0';
  textArea.style.left = '0';
  textArea.style.width = '2em';
  textArea.style.height = '2em';
  textArea.style.padding = '0';
  textArea.style.border = 'none';
  textArea.style.outline = 'none';
  textArea.style.boxShadow = 'none';
  textArea.style.background = 'transparent';
  textArea.value = text;
  document.body.appendChild(textArea);
  textArea.select();
  try {
    var successful = document.execCommand('copy');
    if (successful) {
      Message.success('成功复制到剪贴板')
    } else {
      Message.error('该浏览器不支持点击复制到剪贴板');
    }
  } catch (err) {
    Message.error('该浏览器不支持点击复制到剪贴板');
  }
  document.body.removeChild(textArea);
}

// 版本对比
export function compareVersion(v1, v2) {
  v1 = v1.split('.')
  v2 = v2.split('.')
  const len = Math.max(v1.length, v2.length)
  // 调整两个版本号位数相同
  while (v1.length < len) {
    v1.push('0')
  }
  while (v2.length < len) {
    v2.push('0')
  }
  // 循环判断每位数的大小
  for (let i = 0; i < len; i++) {
    const num1 = parseInt(v1[i])
    const num2 = parseInt(v2[i])
    if (num1 > num2) {
      return 1
    } else if (num1 < num2) {
      return -1
    }
  }
  return 0
}