import axios from 'axios'
import { Message } from '@alifd/next';
import { urlParse } from './index'

const getEnv = () => {
  const query = urlParse()
  // 如果查询参数有环境标识符
  if (query.env) {
    return ['daily', 'pre', 'prod'].includes(query.env) ? query.env : 'prod'
  } else {
    const hostname = window.location.hostname
    if (hostname === '127.0.0.1' || hostname === 'localhost') return 'daily'
    if (hostname.startsWith('pre-')) return 'pre'
    return 'prod'
  }
}
const env = getEnv()
const baseURL = env === 'daily' ? 'http://server4heroform.fx.alibaba.net' :
  env === 'pre' ? 'https://server4heroform.pre-fx.alibaba-inc.com' : 'https://server4heroform.fx.alibaba-inc.com'

const service = axios.create({
  baseURL,
  timeout: 20000,
  responseType: "json",
  withCredentials: false,
  headers: { "Content-Type": "application/json;charset=utf-8" }
})

// 请求拦截
service.interceptors.request.use(
  config => {
    return config;
  },
  error => {
    return Promise.reject(error);
  }
)

// 响应拦截
service.interceptors.response.use(
  response => {
    if (response.status === 200) {
      const data = response.data
      if (data.success) {
        return Promise.resolve(data);
      } else {
        Message.error(data.message || '请求失败')
        return Promise.reject(data);
      }
    } else {
      Message.error('网络请求失败')
      return Promise.reject(response);
    }
  },
  error => {
    Message.error(error.message || '网络错误')
    return Promise.reject(error);
  }
)

export default service